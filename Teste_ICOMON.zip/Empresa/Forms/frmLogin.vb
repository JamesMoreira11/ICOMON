Imports Microsoft.Win32
Imports System.Configuration
Public Class frmLogin

    Inherits System.Windows.Forms.Form
    Dim bCancela As Boolean
    Friend WithEvents pnStatus As System.Windows.Forms.Panel
    Friend WithEvents lblMsg As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Dim bServidor As Boolean
#Region " Windows Form Designer generated code "

    Property MostraServidor() As Boolean
        Get
            Return bServidor
        End Get
        Set(ByVal value As Boolean)
            bServidor = value
        End Set
    End Property

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtLogin As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents cmdSair As System.Windows.Forms.Button
    Friend WithEvents txtSenha As System.Windows.Forms.TextBox

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLogin))
        Me.txtLogin = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtSenha = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.cmdSair = New System.Windows.Forms.Button()
        Me.pnStatus = New System.Windows.Forms.Panel()
        Me.lblMsg = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnStatus.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtLogin
        '
        Me.txtLogin.Location = New System.Drawing.Point(88, 32)
        Me.txtLogin.MaxLength = 30
        Me.txtLogin.Name = "txtLogin"
        Me.txtLogin.Size = New System.Drawing.Size(144, 20)
        Me.txtLogin.TabIndex = 0
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(88, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(43, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Usu�rio"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(24, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 50)
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'txtSenha
        '
        Me.txtSenha.Location = New System.Drawing.Point(88, 80)
        Me.txtSenha.MaxLength = 30
        Me.txtSenha.Name = "txtSenha"
        Me.txtSenha.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSenha.Size = New System.Drawing.Size(144, 20)
        Me.txtSenha.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(88, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Senha"
        '
        'Button1
        '
        Me.Button1.AutoEllipsis = True
        Me.Button1.Location = New System.Drawing.Point(272, 32)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 24)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "OK"
        '
        'cmdSair
        '
        Me.cmdSair.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdSair.Location = New System.Drawing.Point(272, 64)
        Me.cmdSair.Name = "cmdSair"
        Me.cmdSair.Size = New System.Drawing.Size(75, 24)
        Me.cmdSair.TabIndex = 5
        Me.cmdSair.Text = "Sair"
        '
        'pnStatus
        '
        Me.pnStatus.BackColor = System.Drawing.Color.Gainsboro
        Me.pnStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnStatus.Controls.Add(Me.lblMsg)
        Me.pnStatus.Controls.Add(Me.Panel1)
        Me.pnStatus.Location = New System.Drawing.Point(61, 32)
        Me.pnStatus.Name = "pnStatus"
        Me.pnStatus.Size = New System.Drawing.Size(275, 59)
        Me.pnStatus.TabIndex = 85
        Me.pnStatus.Visible = False
        '
        'lblMsg
        '
        Me.lblMsg.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.5!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMsg.ForeColor = System.Drawing.Color.Black
        Me.lblMsg.Location = New System.Drawing.Point(3, 26)
        Me.lblMsg.Name = "lblMsg"
        Me.lblMsg.Size = New System.Drawing.Size(267, 23)
        Me.lblMsg.TabIndex = 82
        Me.lblMsg.Text = "Configurando Sistema, Aguarde ..."
        Me.lblMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.CornflowerBlue
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(274, 22)
        Me.Panel1.TabIndex = 81
        '
        'frmLogin
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.cmdSair
        Me.ClientSize = New System.Drawing.Size(368, 222)
        Me.ControlBox = False
        Me.Controls.Add(Me.pnStatus)
        Me.Controls.Add(Me.cmdSair)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtSenha)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtLogin)
        Me.Controls.Add(Me.Label5)
        Me.KeyPreview = True
        Me.Name = "frmLogin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnStatus.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSair.Click
        If cmdSair.Text = "Sair" Then
            bCancela = True
            End
        Else
            Me.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try

            If txtLogin.Text = "" Then
                msgAviso("Informe o Usu�rio")
                txtLogin.Focus()
                Exit Sub
            ElseIf txtSenha.Text = "" Then
                msgAviso("Informe a Senha")
                txtSenha.Focus()
                Exit Sub
            End If

            Dim sPath As String = Application.StartupPath

            psServidor = "ISSDES"

            Interfaces.bNFSEHomologacao = True

            If OpenConnect(txtLogin.Text, txtSenha.Text) Then
                pnStatus.Visible = True

                Application.DoEvents()
                psLogin = txtLogin.Text.Trim.ToUpper
                psSenha = txtSenha.Text

                frmMDI.Text = Application.ProductName & " (Vers�o " & My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor & "." & My.Application.Info.Version.Build & "." & My.Application.Info.Version.Revision & ") - Usu�rio Atual: " & psNomUsuario & " - Servidor : " & psServidor

                pnStatus.Visible = False
                Application.DoEvents()

                frmMDI.Show()

                FRM_CB03_1.Show()
                FRM_CB03_1.Select()

            End If
        Catch ex As Exception
            MessageBox.Show("Erro ao entrar no sistema" & vbCrLf & ex.Message.ToString())
        End Try

    End Sub

    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            bVigencia_Senha = True

            If bSplash Then
                frmSplash.Show()
                My.Application.DoEvents()
                System.Threading.Thread.Sleep(2300)
            Else
                cmdSair.Text = "Cancelar"
            End If

        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try
        txtSenha.Focus()

    End Sub
    
    Private Sub txtLogin_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLogin.Leave
        txtLogin.Text = UCase(txtLogin.Text)
        txtSenha.Focus()
        If bCancela Then Exit Sub

    End Sub

    Private Sub txtSenha_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtSenha.Leave
        Button1.Focus()
    End Sub

    Private Sub frmLogin_Activated(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Activated
    End Sub

    Private Sub txtSenha_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSenha.KeyDown
        If e.KeyCode = Keys.Return Then
            Button1_Click(Me, New EventArgs)
        End If
    End Sub

End Class
