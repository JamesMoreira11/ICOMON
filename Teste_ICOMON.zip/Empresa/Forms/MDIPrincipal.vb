﻿Imports System.IO
Imports System.Text
Imports System.Xml
Imports System.Xml.Schema
Imports System.Data.OracleClient
Imports System.Security.Cryptography.X509Certificates
Imports System.Collections.Generic
Imports System.Collections.Specialized
Imports System.Security.Cryptography
Imports System.Security.Cryptography.Xml
Imports System.Math

Imports System.Windows.Forms
Imports System
Imports System.Reflection

Imports Microsoft.Win32

Public Class MDIPrincipal
    '*** Constantes do Menu
    Const cMnuPrincipal As String = "Principal"
    Const cMnuSair As String = "Sair"
    Const cMnuAbrir As String = "Abrir"
    Const cMnuFechar As String = "Fechar"
    Const cMnuEditar As String = "Editar"
    Const cMnuCopiar As String = "Copiar"
    Const cMnuColar As String = "Colar"
    Const cMnuRecortar As String = "Recortar"

    Dim sArqTecnico As String

    Public Structure FLASHWINFO
        Public cbSize As Int32
        Public hwnd As IntPtr
        Public dwFlags As Int32
        Public uCount As Int32
        Public dwTimeout As Int32
    End Structure

    Structure AppInfo
        Dim Name As String
        Dim Version As String
        Dim UnInstallPath As String
        Dim SilentUnInstallPath As String
    End Structure

    Private Declare Function FlashWindowEx Lib "user32.dll" (ByRef pfwi As FLASHWINFO) As Int32

    Private Declare Function SetForegroundWindow Lib "user32" (ByVal hwnd As IntPtr) As Long

    Private Declare Auto Function FindWindow Lib "user32.dll" (ByVal lpClassName As String, _
                                                               ByVal lpWindowName As String) As IntPtr

    Private Declare Auto Function FindWindowEx Lib "user32.dll" (ByVal hwndParent As IntPtr, _
                                                                 ByVal hwndChildAfter As IntPtr, _
                                                                 ByVal lpszClass As String, _
                                                                 ByVal lpszWindow As String) As IntPtr

    Private Const FLASHW_CAPTION As Int32 = &H1
    Private Const FLASHW_TRAY As Int32 = &H2
    Private Const FLASHW_ALL As Int32 = (FLASHW_CAPTION Or FLASHW_TRAY)

    Private Sub MDIPrincipal_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        End
    End Sub

    Private Sub MDIPrincipal_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            System.Windows.Forms.Cursor.Current = Cursors.Default
            Me.WindowState = FormWindowState.Maximized

            If My.Application.IsNetworkDeployed Then
                'Não é possível exibir em debug, somente após publicado
                lblVersao.Text += My.Application.Deployment.CurrentVersion.ToString()
                lblVersaoAtual.Text = lblVersao.Text.Trim
            End If

            FRM_CB03_1.Show()

        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try

        FRM_CB03_1.Show()

    End Sub

    Function GetInstalledApps(ByVal rTarget As Microsoft.Win32.RegistryKey, ByVal strNameApp As String) As List(Of AppInfo)
        Dim DestKey As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\"
        Dim iList As New List(Of AppInfo)
        Dim rk As Microsoft.Win32.RegistryKey
        For Each App As String In rTarget.OpenSubKey(DestKey).GetSubKeyNames
            rk = rTarget.OpenSubKey(DestKey & App & "\")
            If Not rk.GetValue("DisplayName") Is Nothing AndAlso _
                   rk.GetValue("DisplayName").ToString.IndexOf(strNameApp) > -1 Then

                iList.Add(New AppInfo With {.Name = rk.GetValue("DisplayName"), _
                                            .Version = rk.GetValue("DisplayVersion"), _
                                            .UnInstallPath = rk.GetValue("UninstallString")})
            End If
        Next
        Return iList
    End Function

    Public Sub MontaMenu(ByVal NomeMenu As Form)
        Cursor = Cursors.WaitCursor
        NomeMenu.WindowState = FormWindowState.Normal
        NomeMenu.MdiParent = Me
        NomeMenu.Show()
        NomeMenu.BringToFront()
        Cursor = Cursors.Default
    End Sub

    Public Sub MenuStrip_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MenuStrip.Click
        Try
            psSubcontrato = 0
            oCB03_1 = New FRM_CB03_1 : MontaMenu(oCB03_1)
            Select Case Trim(Mid(sender.ToString, 1, 5))
                Case "Logo"
                    Dim frm As New frmLogin
                    frm.MostraServidor = True
                    frm.ShowDialog()
                Case "Sair"
                    bSair = True
                    FecharSistema()
            End Select
        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try
    End Sub

    Private Sub MDIPrincipal_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        bSair = True
        FecharSistema()
        frmMDI = Nothing
    End Sub

    Private Sub FecharSistema()
        If bSair Then
            CloseConnect()
            End
        End If
    End Sub

    Private Sub AtualizaDataEmissao()
        pDatEmissao = lblDataEmissaoNF.Text
    End Sub

    Private Sub MDIPrincipal_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F12 Then
            Dim frm As New frmLogin
            frm.MostraServidor = True
            frm.ShowDialog()
        End If
    End Sub

    Private Sub MDIPrincipal_Load_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class