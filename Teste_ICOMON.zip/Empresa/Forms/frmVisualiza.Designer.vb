<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmVisualiza
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgDados = New System.Windows.Forms.DataGridView()
        Me.CAMPO1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgDados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgDados
        '
        Me.dgDados.AllowUserToAddRows = False
        Me.dgDados.AllowUserToDeleteRows = False
        Me.dgDados.AllowUserToOrderColumns = True
        Me.dgDados.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDados.CausesValidation = False
        Me.dgDados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDados.ColumnHeadersVisible = False
        Me.dgDados.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CAMPO1})
        Me.dgDados.Location = New System.Drawing.Point(6, 12)
        Me.dgDados.Name = "dgDados"
        Me.dgDados.ReadOnly = True
        Me.dgDados.RowHeadersVisible = False
        Me.dgDados.RowTemplate.Height = 18
        Me.dgDados.ShowEditingIcon = False
        Me.dgDados.ShowRowErrors = False
        Me.dgDados.Size = New System.Drawing.Size(193, 167)
        Me.dgDados.TabIndex = 87
        '
        'CAMPO1
        '
        Me.CAMPO1.DataPropertyName = "CAMPO1"
        Me.CAMPO1.HeaderText = "Status"
        Me.CAMPO1.Name = "CAMPO1"
        Me.CAMPO1.ReadOnly = True
        '
        'frmVisualiza
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(206, 191)
        Me.Controls.Add(Me.dgDados)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmVisualiza"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmVisualiza"
        CType(Me.dgDados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dgDados As System.Windows.Forms.DataGridView
    Friend WithEvents CAMPO1 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
