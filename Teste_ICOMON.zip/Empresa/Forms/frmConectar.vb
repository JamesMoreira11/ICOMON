Public Class frmConectar

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        pbAlterouConexao = True
        Me.Close()

    End Sub

    Private Sub cmdSair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    Private Sub frmConectar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'txtServidor.Text = psServidor

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Visible = False
        If frmMDI.Visible Then
            FecharForms()
        End If
        piCodUnidade = cboUnidade.SelectedValue
        AtualizaDataEmissao()


        'Pega nome do servidor
        frmMDI.Text = Application.ProductName & " (Vers�o " & My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor & "." & My.Application.Info.Version.Build & "." & My.Application.Info.Version.Revision & ") - Usu�rio Atual: " & psNomUsuario & " - Servidor : " & psServidor
        Dim oMenu As New clsMenu
        oMenu.PrepararMenu()
        frmMDI.Timer1.Enabled = True
        psNomUnidade = cboUnidade.Text
        frmMDI.lblUnidade.Text = psNomUnidade
        Application.DoEvents()
        SaveSetting("SFI", "Login", "Unidade", cboUnidade.SelectedValue)
        If Not frmMDI.Visible Then
            Try
                frmMDI.Show()
            Catch ex As Exception
                msgErro(ex.Message, ex)
            End Try
        End If


    End Sub
    Private Sub AtualizaDataEmissao()

    End Sub

End Class