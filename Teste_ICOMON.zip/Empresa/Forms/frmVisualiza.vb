Public Class frmVisualiza

    Private Sub dgDados_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dgDados.DoubleClick
        For x As Int16 = 0 To dgDados.RowCount - 1
            If VerificaColunaSelecionada(dgDados, x) Then
                Dim dc As DataGridViewRow = sender.rows(x)
                psCodPesquisa = dc.Cells("CAMPO1").Value
                Me.Close()
                Exit For
            End If
        Next

    End Sub

    Private Sub frmVisualiza_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class