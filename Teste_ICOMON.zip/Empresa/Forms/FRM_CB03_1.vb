﻿Public Class FRM_CB03_1
    Dim oDominio As New clsDominio
    Dim sDscSituacao As String
    Dim iCodSituacao As Int16

    Private Sub FRM_CB03_1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        txtFunc.Focus()
    End Sub

    Private Sub FRM_FT04_1_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
    End Sub

    Private Sub FRM_CB03_1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            CarregaCombo()
        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try

    End Sub
    Private Sub CarregaCombo()

    End Sub

    Private Sub ToolBar1_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar1.ButtonClick
        If e.Button.Text = "Sair" Then
            Me.Close()
        ElseIf e.Button.Text = "Limpar" Then
            LimpaCampos()
        End If

    End Sub
    Private Sub LimpaCampos()
        txtFunc.Text = ""
        txtPessoa.Text = ""
        txtMatricula.Text = ""
        txtNome.Text = ""
        txtNasc.Text = ""
        txtSuperior.Text = ""

    End Sub
    Private Sub CarregaCampos(ByVal dt As DataTable)

        LimpaCampos()
        txtNome.Text = dt.Rows(0)("Nome").ToString
        txtMatricula.Text = dt.Rows(0)("Matricula").ToString
        txtPessoa.Text = dt.Rows(0)("Nome").ToString
        txtNasc.Text = dt.Rows(0)("DataNasc").ToString
        txtSuperior.Text = dt.Rows(0)("Superior").ToString

    End Sub
    Private Sub cmdAssociado_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAssociado.Click
        ProcuraPessoa(False)
    End Sub
    Private Sub ProcuraPessoa(ByVal bCampo As Boolean)

        If bCampo Then
            If txtFunc.Text <> "" Then
                Dim sSQL As String = " select * " & _
                             " from Funcionarios " & _
                             " where Id_Func = " & txtFunc.Text
                Dim dt As DataTable = ExecuteRecordset(sSQL)
                If dt.Rows.Count > 0 Then
                    txtFunc.Text = dt.Rows(0)("ID_Func")
                    txtPessoa.Text = dt.Rows(0)("Nome")
                    CarregaCampos(dt)
                Else
                    msgAviso("Funcionario não cadastrado")
                    LimpaCampos()
                    txtFunc.Text = ""
                    txtPessoa.Text = ""
                End If
            End If
        End If
    End Sub
    Private Sub txtPessoa_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFunc.Leave
        ProcuraPessoa(True)
    End Sub

    Private Sub FRM_CB03_1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        oCB03_1 = Nothing
        Me.Dispose()
    End Sub

End Class