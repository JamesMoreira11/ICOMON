﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FRM_CB03_1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FRM_CB03_1))
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolBar1 = New System.Windows.Forms.ToolBar()
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton7 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton9 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton8 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton()
        Me.FR_FT06_2 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtPessoa = New System.Windows.Forms.TextBox()
        Me.cmdAssociado = New System.Windows.Forms.Button()
        Me.txtFunc = New System.Windows.Forms.TextBox()
        Me.LA_ASSOCIADO = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtMatricula = New System.Windows.Forms.TextBox()
        Me.txtNome = New System.Windows.Forms.TextBox()
        Me.txtNasc = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSuperior = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FR_FT06_2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "")
        Me.ImageList1.Images.SetKeyName(1, "")
        Me.ImageList1.Images.SetKeyName(2, "")
        Me.ImageList1.Images.SetKeyName(3, "")
        Me.ImageList1.Images.SetKeyName(4, "")
        Me.ImageList1.Images.SetKeyName(5, "")
        Me.ImageList1.Images.SetKeyName(6, "")
        Me.ImageList1.Images.SetKeyName(7, "")
        Me.ImageList1.Images.SetKeyName(8, "")
        Me.ImageList1.Images.SetKeyName(9, "")
        '
        'ToolBar1
        '
        Me.ToolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar1.AutoSize = False
        Me.ToolBar1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ToolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton2, Me.ToolBarButton3, Me.ToolBarButton7, Me.ToolBarButton4, Me.ToolBarButton5, Me.ToolBarButton9, Me.ToolBarButton8, Me.ToolBarButton6})
        Me.ToolBar1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ToolBar1.DropDownArrows = True
        Me.ToolBar1.ImageList = Me.ImageList1
        Me.ToolBar1.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar1.Name = "ToolBar1"
        Me.ToolBar1.ShowToolTips = True
        Me.ToolBar1.Size = New System.Drawing.Size(787, 40)
        Me.ToolBar1.TabIndex = 54
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 0
        Me.ToolBarButton2.Name = "ToolBarButton2"
        Me.ToolBarButton2.Text = "Novo"
        Me.ToolBarButton2.ToolTipText = "Limpar Todos os Campos"
        Me.ToolBarButton2.Visible = False
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 1
        Me.ToolBarButton3.Name = "ToolBarButton3"
        Me.ToolBarButton3.Text = "Alterar"
        Me.ToolBarButton3.ToolTipText = "Alterar registro"
        Me.ToolBarButton3.Visible = False
        '
        'ToolBarButton7
        '
        Me.ToolBarButton7.ImageIndex = 6
        Me.ToolBarButton7.Name = "ToolBarButton7"
        Me.ToolBarButton7.Text = "Cancelar"
        Me.ToolBarButton7.ToolTipText = "Excluir registro"
        Me.ToolBarButton7.Visible = False
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.Enabled = False
        Me.ToolBarButton4.ImageIndex = 2
        Me.ToolBarButton4.Name = "ToolBarButton4"
        Me.ToolBarButton4.Text = "Salvar"
        Me.ToolBarButton4.ToolTipText = "Salvar registro"
        Me.ToolBarButton4.Visible = False
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 3
        Me.ToolBarButton5.Name = "ToolBarButton5"
        Me.ToolBarButton5.Text = "Limpar"
        Me.ToolBarButton5.ToolTipText = "Cancelar"
        '
        'ToolBarButton9
        '
        Me.ToolBarButton9.ImageIndex = 7
        Me.ToolBarButton9.Name = "ToolBarButton9"
        Me.ToolBarButton9.Text = "Pesquisar"
        Me.ToolBarButton9.ToolTipText = "Pesquisar"
        Me.ToolBarButton9.Visible = False
        '
        'ToolBarButton8
        '
        Me.ToolBarButton8.ImageIndex = 5
        Me.ToolBarButton8.Name = "ToolBarButton8"
        Me.ToolBarButton8.Text = "Relatório Geral"
        Me.ToolBarButton8.ToolTipText = "Relatório Geral"
        Me.ToolBarButton8.Visible = False
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 4
        Me.ToolBarButton6.Name = "ToolBarButton6"
        Me.ToolBarButton6.Text = "Sair"
        Me.ToolBarButton6.ToolTipText = "Sair"
        '
        'FR_FT06_2
        '
        Me.FR_FT06_2.BackColor = System.Drawing.SystemColors.Control
        Me.FR_FT06_2.Controls.Add(Me.txtSuperior)
        Me.FR_FT06_2.Controls.Add(Me.Label4)
        Me.FR_FT06_2.Controls.Add(Me.txtNasc)
        Me.FR_FT06_2.Controls.Add(Me.Label2)
        Me.FR_FT06_2.Controls.Add(Me.txtNome)
        Me.FR_FT06_2.Controls.Add(Me.txtMatricula)
        Me.FR_FT06_2.Controls.Add(Me.Label1)
        Me.FR_FT06_2.Controls.Add(Me.Label3)
        Me.FR_FT06_2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FR_FT06_2.Location = New System.Drawing.Point(12, 112)
        Me.FR_FT06_2.Name = "FR_FT06_2"
        Me.FR_FT06_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FR_FT06_2.Size = New System.Drawing.Size(761, 232)
        Me.FR_FT06_2.TabIndex = 55
        Me.FR_FT06_2.TabStop = False
        Me.FR_FT06_2.Text = "Dados Cadastrais"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(18, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 62
        Me.Label3.Text = "Matricula"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Controls.Add(Me.txtPessoa)
        Me.GroupBox1.Controls.Add(Me.cmdAssociado)
        Me.GroupBox1.Controls.Add(Me.txtFunc)
        Me.GroupBox1.Controls.Add(Me.LA_ASSOCIADO)
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 46)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox1.Size = New System.Drawing.Size(761, 49)
        Me.GroupBox1.TabIndex = 57
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Seleção"
        '
        'txtPessoa
        '
        Me.txtPessoa.AcceptsReturn = True
        Me.txtPessoa.BackColor = System.Drawing.Color.Gainsboro
        Me.txtPessoa.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPessoa.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPessoa.Location = New System.Drawing.Point(283, 12)
        Me.txtPessoa.MaxLength = 0
        Me.txtPessoa.Name = "txtPessoa"
        Me.txtPessoa.ReadOnly = True
        Me.txtPessoa.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPessoa.Size = New System.Drawing.Size(467, 20)
        Me.txtPessoa.TabIndex = 3
        '
        'cmdAssociado
        '
        Me.cmdAssociado.ImageIndex = 7
        Me.cmdAssociado.ImageList = Me.ImageList1
        Me.cmdAssociado.Location = New System.Drawing.Point(230, 13)
        Me.cmdAssociado.Name = "cmdAssociado"
        Me.cmdAssociado.Size = New System.Drawing.Size(26, 23)
        Me.cmdAssociado.TabIndex = 34
        Me.cmdAssociado.UseVisualStyleBackColor = True
        '
        'txtFunc
        '
        Me.txtFunc.AcceptsReturn = True
        Me.txtFunc.BackColor = System.Drawing.SystemColors.Window
        Me.txtFunc.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFunc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFunc.Location = New System.Drawing.Point(112, 13)
        Me.txtFunc.MaxLength = 0
        Me.txtFunc.Name = "txtFunc"
        Me.txtFunc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFunc.Size = New System.Drawing.Size(108, 20)
        Me.txtFunc.TabIndex = 2
        '
        'LA_ASSOCIADO
        '
        Me.LA_ASSOCIADO.AutoSize = True
        Me.LA_ASSOCIADO.BackColor = System.Drawing.SystemColors.Control
        Me.LA_ASSOCIADO.Cursor = System.Windows.Forms.Cursors.Default
        Me.LA_ASSOCIADO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LA_ASSOCIADO.Location = New System.Drawing.Point(8, 16)
        Me.LA_ASSOCIADO.Name = "LA_ASSOCIADO"
        Me.LA_ASSOCIADO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LA_ASSOCIADO.Size = New System.Drawing.Size(98, 13)
        Me.LA_ASSOCIADO.TabIndex = 33
        Me.LA_ASSOCIADO.Text = "Codigo Funcionario"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(18, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 64
        Me.Label1.Text = "Nome"
        '
        'txtMatricula
        '
        Me.txtMatricula.AcceptsReturn = True
        Me.txtMatricula.BackColor = System.Drawing.SystemColors.Window
        Me.txtMatricula.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMatricula.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMatricula.Location = New System.Drawing.Point(76, 22)
        Me.txtMatricula.MaxLength = 0
        Me.txtMatricula.Name = "txtMatricula"
        Me.txtMatricula.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMatricula.Size = New System.Drawing.Size(108, 20)
        Me.txtMatricula.TabIndex = 65
        '
        'txtNome
        '
        Me.txtNome.AcceptsReturn = True
        Me.txtNome.BackColor = System.Drawing.SystemColors.Window
        Me.txtNome.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNome.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNome.Location = New System.Drawing.Point(76, 60)
        Me.txtNome.MaxLength = 0
        Me.txtNome.Name = "txtNome"
        Me.txtNome.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNome.Size = New System.Drawing.Size(419, 20)
        Me.txtNome.TabIndex = 66
        '
        'txtNasc
        '
        Me.txtNasc.AcceptsReturn = True
        Me.txtNasc.BackColor = System.Drawing.SystemColors.Window
        Me.txtNasc.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNasc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNasc.Location = New System.Drawing.Point(113, 104)
        Me.txtNasc.MaxLength = 0
        Me.txtNasc.Name = "txtNasc"
        Me.txtNasc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNasc.Size = New System.Drawing.Size(108, 20)
        Me.txtNasc.TabIndex = 68
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(18, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(89, 13)
        Me.Label2.TabIndex = 67
        Me.Label2.Text = "Data Nascimento"
        '
        'txtSuperior
        '
        Me.txtSuperior.AcceptsReturn = True
        Me.txtSuperior.BackColor = System.Drawing.SystemColors.Window
        Me.txtSuperior.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSuperior.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSuperior.Location = New System.Drawing.Point(76, 152)
        Me.txtSuperior.MaxLength = 0
        Me.txtSuperior.Name = "txtSuperior"
        Me.txtSuperior.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSuperior.Size = New System.Drawing.Size(108, 20)
        Me.txtSuperior.TabIndex = 70
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(18, 152)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(46, 13)
        Me.Label4.TabIndex = 69
        Me.Label4.Text = "Superior"
        '
        'FRM_CB03_1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(787, 353)
        Me.Controls.Add(Me.FR_FT06_2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ToolBar1)
        Me.Name = "FRM_CB03_1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cadastro de Funcionarios"
        Me.FR_FT06_2.ResumeLayout(False)
        Me.FR_FT06_2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents ToolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton7 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton9 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton8 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    Public WithEvents FR_FT06_2 As System.Windows.Forms.GroupBox
    Public WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdAssociado As System.Windows.Forms.Button
    Public WithEvents txtFunc As System.Windows.Forms.TextBox
    Public WithEvents LA_ASSOCIADO As System.Windows.Forms.Label
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents txtPessoa As System.Windows.Forms.TextBox
    Public WithEvents txtSuperior As System.Windows.Forms.TextBox
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents txtNasc As System.Windows.Forms.TextBox
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents txtNome As System.Windows.Forms.TextBox
    Public WithEvents txtMatricula As System.Windows.Forms.TextBox
    Public WithEvents Label1 As System.Windows.Forms.Label
End Class
