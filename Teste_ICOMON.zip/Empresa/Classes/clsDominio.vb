﻿Public Class clsDominio
    Public Function InsereDominio(ByVal CodDominio As String, _
                                  ByVal NomDominio As String, _
                                  ByVal dc As DataGridViewRow)

        Dim bRet As Boolean
        Dim sSQL As String
        Try

            sSQL = "INSERT INTO PCB_DOMINIO (COD_DOMINIO,NOM_DOMINIO," & _
                                "COD_ITEM_DOMINIO,DSC_COMPLETA_ITEM,DSC_ABREVIADA_ITEM," & _
                                "COD_SUB_DOMINIO,COD_SUB_ITEM_DOMINIO, " & _
                                "COD_USUARIO_INCLUSAO,DAT_USUARIO_INCLUSAO," & _
                                "COD_USUARIO_ALTERACAO,DAT_USUARIO_ALTERACAO) VALUES('" & _
                                CodDominio & "','" & NomDominio & "'," & _
                                dc.Cells("COD_ITEM_DOMINIO").Value & ",'" & dc.Cells("DSC_COMPLETA_ITEM").Value & "','" & dc.Cells("DSC_ABREVIADA_ITEM").Value & "',"
            If dc.Cells("COD_SUB_DOMINIO").Value <> "" Then
                sSQL += "'" & dc.Cells("COD_SUB_DOMINIO").Value & "',"
            Else
                sSQL += "NULL,"
            End If
            If dc.Cells("COD_SUB_ITEM_DOMINIO").Value <> "" Then
                sSQL += "'" & dc.Cells("COD_SUB_ITEM_DOMINIO").Value & "',"
            Else
                sSQL += "NULL,"
            End If

            sSQL += "'" & psLogin & "',SYSDATE,'" & psLogin & "'," & "SYSDATE)"

            bRet = ExecuteSQL(sSQL)
        Catch ex As Exception
            msgErro(ex.Message)
        End Try

        Return bRet

    End Function

    Public Function AlteraDominio(ByVal CodDominio As String, ByVal NomeDominio As String, _
                                  ByVal dc As DataGridViewRow) As Boolean

        Dim bRet As Boolean
        Try
            Dim sSQL As String = "UPDATE PCB_DOMINIO SET " & _
                                "NOM_DOMINIO='" & NomeDominio & "'," & _
                                "DSC_COMPLETA_ITEM='" & dc.Cells("DSC_COMPLETA_ITEM").Value & "'," & _
                                "DSC_ABREVIADA_ITEM='" & dc.Cells("DSC_ABREVIADA_ITEM").Value & "'," & _
                                "COD_SUB_DOMINIO='" & dc.Cells("COD_SUB_DOMINIO").Value & "'," & _
                                "COD_SUB_ITEM_DOMINIO='" & dc.Cells("COD_SUB_ITEM_DOMINIO").Value & "'," & _
                                "COD_USUARIO_ALTERACAO='" & psLogin & "'," & _
                                "DAT_USUARIO_ALTERACAO=SYSDATE WHERE " & _
                                "COD_DOMINIO= '" & CodDominio & "'" & _
                                " AND COD_ITEM_DOMINIO = " & dc.Cells("COD_ITEM_DOMINIO").Value

            bRet = ExecuteSQL(sSQL)
        Catch ex As Exception
            msgErro(ex.Message)
        End Try

        Return bRet

    End Function
    Public Function RemoveItemDominio(ByVal CodDominio As String, _
                                  ByVal dc As DataGridViewRow) As Boolean

        Dim bRet As Boolean
        Try
            Dim sSQL As String = "DELETE PCB_DOMINIO WHERE  " & _
                               "COD_DOMINIO='" & CodDominio & "' AND " & _
                               "COD_ITEM_DOMINIO = " & dc.Cells("COD_ITEM_DOMINIO").Value

            bRet = ExecuteSQL(sSQL)
        Catch ex As Exception
            msgErro(ex.Message)
        End Try

        Return bRet

    End Function

    Public Function SelecionarCodigo(ByVal sCodTabela As String, _
                                     ByVal iCodCampo As Long) As DataTable

        Dim dt As DataTable
        Try
            Dim sSql As String = ""
            sSql = "SELECT "
            sSql = sSql & " DO.COD_ITEM_DOMINIO ,  "
            sSql = sSql & " DO.DSC_COMPLETA_ITEM, DO.DSC_ABREVIADA_ITEM, DO.NOM_DOMINIO, DO.COD_SUB_DOMINIO, NVL(SD.NOM_DOMINIO,'') DSC_SUB_DOMINIO, DO.COD_SUB_ITEM_DOMINIO, NVL(SD.DSC_COMPLETA_ITEM,'') DSC_SUB_ITEM_DOMINIO "
            sSql = sSql & "FROM PCB_DOMINIO DO, PCB_DOMINIO SD "
            sSql = sSql & "WHERE "
            sSql = sSql & " DO.COD_DOMINIO = '" & Trim(sCodTabela) & "'"
            sSql = sSql & " AND SD.COD_DOMINIO(+) = DO.COD_SUB_DOMINIO "
            sSql = sSql & " AND SD.COD_ITEM_DOMINIO(+) = DO.COD_SUB_ITEM_DOMINIO"

            If iCodCampo > 0 Then
                sSql = sSql & " AND COD_ITEM_DOMINIO = '" & iCodCampo & "'"
            End If
            sSql = sSql & " ORDER BY DO.DSC_COMPLETA_ITEM "

            dt = ExecuteRecordset(sSql)

        Catch ex As Exception
            msgErro(ex.Message)
            dt = New DataTable
        End Try

        Return dt

    End Function


End Class
