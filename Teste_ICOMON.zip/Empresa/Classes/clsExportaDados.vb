﻿Imports System.Text
Imports System.IO
Imports System.Linq

Public Class clsExportaDados

    ''' <summary>
    ''' ''' Exporta um DataTable para CSV
    ''' Atenção: pode gerar excessão caso não tenha dados ou ao salvar o arquivo
    ''' </summary>
    ''' <param name="dg">Grid (DataGridView)</param> 
    ''' <param name="incluirCabecalho">Incluir o nome das colunas no arquivo CSV</param>
    ''' <param name="separador">Separador dos valores, por padrão ','</param>
    ''' <param name="nomeArquivo">Nome do arquivo a ser salvo (se em branco ira exibir pro usuario informar)</param>
    ''' <param name="substituirValorComSeparador">Substitui uma string pelo separador (força a gerar uma nova coluna)</param>
    ''' <returns>Path do arquivo gerado</returns>
    ''' <remarks></remarks>
    Public Function ExportarCSV(dg As DataGridView, incluirCabecalho As Boolean, Optional separador As String = ";", Optional nomeArquivo As String = "", Optional ByVal substituirValorComSeparador As String = "") As String
        Dim dt As DataTable

        'se a grid utiliza um datatable, recupera e exporta
        dt = CType(dg.DataSource, DataTable)
        If (dt IsNot Nothing AndAlso dt.Columns.Count > 0 AndAlso dt.Rows.Count > 0) Then
            ExportarCSV(dt.Copy, incluirCabecalho, separador, nomeArquivo)
            Return String.Empty
        End If

        If (dg Is Nothing OrElse dg.Columns.Count = 0 OrElse dg.Rows.Count = 0) Then
            msgErro("Não há dados a serem exportados!")
            Return String.Empty
        End If

        'converte a grid (colunas e linhas) em um datatable
        dt = New DataTable
        For Each col As DataGridViewColumn In dg.Columns
            dt.Columns.Add(col.Name, IIf(col.ValueType Is Nothing, GetType(String), col.ValueType))
        Next

        For i As Integer = 0 To dg.Rows.Count - 1
            Dim row As DataRow = dt.NewRow
            For c As Integer = 0 To dg.Columns.Count - 1
                row(c) = dg.Rows(i).Cells(c).Value()
            Next
            dt.Rows.Add(row)
        Next

        Return ExportarCSV(dt, incluirCabecalho, separador, nomeArquivo, substituirValorComSeparador)
    End Function

    ''' <summary>
    ''' Exporta um DataTable para CSV
    ''' Atenção: pode gerar excessão caso não tenha dados no datatable ou ao salvar o arquivo
    ''' </summary>
    ''' <param name="dt">DataTable com os dados</param>
    ''' <param name="incluirCabecalho">Incluir o nome das colunas no arquivo CSV</param>
    ''' <param name="separador">Separador dos valores, por padrão ','</param>
    ''' <param name="nomeArquivo">Nome do arquivo a ser salvo (se em branco ira exibir pro usuario informar)</param>
    ''' <param name="substituirValorComSeparador">Substitui uma string pelo separador (força a gerar uma nova coluna)</param>
    ''' <returns>Path do arquivo gerado</returns>
    ''' <remarks></remarks>
    Public Function ExportarCSV(dt As DataTable, incluirCabecalho As Boolean, Optional separador As String = ";", Optional nomeArquivo As String = "", Optional ByVal substituirValorComSeparador As String = "") As String
        Dim sb As New StringBuilder

        If (dt Is Nothing OrElse dt.Columns.Count = 0 OrElse dt.Rows.Count = 0) Then
            msgErro("Não há dados a serem exportados!")
            Return String.Empty
        End If

        Dim localSalvarArquivo As String = PerguntarSalvarArquivo(nomeArquivo)
        If (String.IsNullOrWhiteSpace(localSalvarArquivo)) Then
            Return String.Empty
        End If

        If (incluirCabecalho) Then
            Dim colunas As String() = dt.Columns.Cast(Of DataColumn).Select(Of String)(Function(col) TrataCampoComSeparador(col.ColumnName, separador, substituirValorComSeparador)).ToArray()
            sb.AppendLine(String.Join(separador, colunas))
        End If

        For Each row As DataRow In dt.Rows
            Dim campos As String() = row.ItemArray.Select(Of String)(Function(campo) TrataCampoComSeparador(campo.ToString(), separador, substituirValorComSeparador)).ToArray()
            sb.AppendLine(String.Join(separador, campos))
        Next row

        Try
            File.AppendAllText(localSalvarArquivo, sb.ToString, Encoding.UTF8)
            Return localSalvarArquivo
        Catch ex As Exception
            msgErro("Falha ao exportar o arquivo.", ex)
        End Try
    End Function

    ''' <summary>
    ''' Caso o valor contem o seprador, adiciona aspa duplas no valor
    ''' </summary>
    ''' <param name="valor">Valor do campo a verificar</param>
    ''' <param name="separador">Separador dos valores</param>
    ''' <returns>Valor tratado caso tenha o separador ou apenas o valor</returns>
    Private Function TrataCampoComSeparador(ByVal valor As String, ByVal separador As String, Optional ByVal substituirValorComSeparador As String = "") As Object
        Dim vlrTratado As Object = valor

        'coloca entre aspas para nao realizar a separacao em outra coluna
        If (vlrTratado.Contains(separador)) Then
            vlrTratado = """" & vlrTratado & """"
        End If

        'substitui um valor especifico pelo separador (forca a gerar outra coluna)
        If (Not String.IsNullOrWhiteSpace(substituirValorComSeparador) AndAlso vlrTratado.Contains(substituirValorComSeparador)) Then
            vlrTratado = vlrTratado.ToString().Replace(substituirValorComSeparador, separador)
        End If

        Return vlrTratado
    End Function

    ''' <summary>
    ''' Exibe um SaveFileDialog para arquivos CSV
    ''' </summary>
    ''' <param name="nomeArquivo">Nome do arquivo, se em branco ira gerar um padrão</param>
    ''' <returns>Retorna o diretorio + arquivo escolhido pelo usuario, ou vazio "" caso usuario cancele</returns>
    Public Function PerguntarSalvarArquivo(Optional ByVal nomeArquivo As String = "") As String

        Using sfd As New SaveFileDialog
            sfd.AutoUpgradeEnabled = False
            sfd.CheckFileExists = False
            sfd.CheckPathExists = True
            sfd.DefaultExt = "csv"
            sfd.FileName = IIf(String.IsNullOrWhiteSpace(nomeArquivo), "CSV_" & DateTime.Now.ToString("ddMMyyyy_hhmmss"), nomeArquivo)
            sfd.Filter = "Arquivo CSV (*.csv)|*.csv"
            sfd.FilterIndex = 0
            sfd.InitialDirectory = FileIO.SpecialDirectories.Desktop
            sfd.OverwritePrompt = True
            sfd.Title = "Salvar arquivo csv"
            If sfd.ShowDialog = DialogResult.OK Then
                Return sfd.FileName
            Else
                'usuario cancelou
                Return String.Empty
            End If
        End Using

    End Function

End Class
