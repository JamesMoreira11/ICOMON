Imports Microsoft.VisualBasic

''' <summary>
''' Simulador
''' </summary>
''' <remarks>Simulador</remarks>
Public Class clsSimulador

    Private _Abrangencia As String
    Private _CodAbrangencia As String
    Private _Plano As String
    Private _FaixaEtaria As String
    Private _Qtd As String
    Private _ValFaixa As String
    Private _Preco As String
    Private _CodPlano As Int64
    Private _IdAbrangencia As Int64

    Public Sub New(ByVal iAbrangencia As String, ByVal iCodAbrangencia As String, ByVal iPlano As String, ByVal iFaixaEtaria As String, ByVal iQtd As String, ByVal iValFaixa As String, ByVal iPreco As String, ByVal iCodPlano As Int64, ByVal iIdAbrangencia As Int64)
        Me.vAbrangencia = iAbrangencia
        Me.vCodAbrangencia = iCodAbrangencia
        Me.vPlano = iPlano
        Me.vFaixaEtaria = iFaixaEtaria
        Me.vQtd = iQtd
        Me.vValFaixa = iValFaixa
        Me.vPreco = iPreco
        Me.vCodPlano = iCodPlano
        Me.vIdAbrangencia = iIdAbrangencia
    End Sub

    Public Property vAbrangencia() As String
        Get
            Return _Abrangencia
        End Get
        Set(ByVal Valor As String)
            _Abrangencia = Valor
        End Set
    End Property

    Public Property vCodAbrangencia() As String
        Get
            Return _CodAbrangencia
        End Get
        Set(ByVal Valor As String)
            _CodAbrangencia = Valor
        End Set
    End Property

    Public Property vPlano() As String
        Get
            Return _Plano
        End Get
        Set(ByVal Valor As String)
            _Plano = Valor
        End Set
    End Property

    Public Property vFaixaEtaria() As String
        Get
            Return _FaixaEtaria
        End Get
        Set(ByVal Valor As String)
            _FaixaEtaria = Valor
        End Set
    End Property

    Public Property vQtd() As String
        Get
            Return _Qtd
        End Get
        Set(ByVal Valor As String)
            _Qtd = Valor
        End Set
    End Property

    Public Property vValFaixa() As String
        Get
            Return _ValFaixa
        End Get
        Set(ByVal Valor As String)
            _ValFaixa = Valor
        End Set
    End Property

    Public Property vPreco() As String
        Get
            Return _Preco
        End Get
        Set(ByVal Valor As String)
            _Preco = Valor
        End Set
    End Property

    Public Property vCodPlano() As String
        Get
            Return _CodPlano
        End Get
        Set(ByVal Valor As String)
            _CodPlano = Valor
        End Set
    End Property

    Public Property vIdAbrangencia() As String
        Get
            Return _IdAbrangencia
        End Get
        Set(ByVal Valor As String)
            _IdAbrangencia = Valor
        End Set
    End Property

End Class
