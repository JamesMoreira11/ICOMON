﻿Public Class clsMenu

    Public Sub PrepararMenu()

        Dim objMenu As New clsMenu
        Dim dt As DataTable
        Dim Click As New EventHandler(AddressOf frmMDI.MenuStrip_Click)

        Dim Janela As New ToolStripMenuItem("Janela", Nothing)
        frmMDI.MenuStrip.MdiWindowListItem = Janela
        frmMDI.MenuStrip.Items.Add(Janela)

        ' método de callback da delegada EventHandler passada como parâmetro
        Dim log As New ToolStripMenuItem("Logoff", Nothing, Click)
        frmMDI.MenuStrip.Items.Add(log)

        ' método de callback da delegada EventHandler passada como parâmetro
        Dim sair As New ToolStripMenuItem("Sair", Nothing, Click)
        frmMDI.MenuStrip.Items.Add(sair)

    End Sub

    Public Sub MontaMenu(ByRef oObj As ToolStripMenuItem, ByVal Click As System.EventHandler, ByVal Menu As String)

        Dim item As New ToolStripMenuItem(Menu, Nothing, Click)
        oObj.DropDownItems.Add(item)

    End Sub

    Public Function GetDataTransacoes(ByRef Login As String, ByRef iCodSistema As Short) As DataTable

        Dim dt As DataTable

        Try

            Dim sSQL As String

            'Se for Administrador monta todo o menu
            sSQL = " SELECT 1 "
            sSQL += " FROM PSS_USUARIO_PERFIL UP "
            sSQL += " WHERE UP.COD_LOGIN_USUARIO='" & Login & "'"
            sSQL += " AND COD_PERFIL=1"
            Dim dtPerfil As DataTable = ExecuteRecordset(sSQL)
            If dtPerfil.Rows.Count = 0 Then
                sSQL = "SELECT DISTINCT " & _
                       " B.COD_TRANSACAO " & _
                       ",C.NOM_TRANSACAO " & _
                       "FROM " & _
                        "PSS_USUARIO_PERFIL A, " & _
                        "PSS_PERFIL_ACESSO B, " & _
                        "PSS_TRANSACAO C " & _
                        "WHERE " & _
                        "A.COD_LOGIN_USUARIO = '" & Login & "' " & _
                        " AND B.COD_PERFIL =  A.COD_PERFIL " & _
                        " AND B.COD_SISTEMA =  " & iCodSistema & _
                        " AND C.COD_SISTEMA = B.COD_SISTEMA " & _
                        " AND C.COD_TRANSACAO = B.COD_TRANSACAO " & _
                        " ORDER BY 1, 2 "
            Else
                sSQL = "SELECT DISTINCT " & _
                       " C.COD_TRANSACAO " & _
                       ",C.NOM_TRANSACAO " & _
                       " FROM PSS_TRANSACAO C " & _
                       " WHERE COD_SISTEMA = " & iCodSistema & _
                       " ORDER BY 1, 2 "
            End If
            dt = ExecuteRecordset(sSQL)

        Catch ex As Exception
            dt = New DataTable
            msgErro(ex.Message)
        End Try

        Return dt

    End Function
End Class