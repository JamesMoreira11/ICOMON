Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports Microsoft.Web.Services3.Design
Imports Microsoft.Web.Services3
Imports System.Xml
Imports Microsoft.Web.Services3.Security.Tokens
Imports Microsoft.Web.Services3.Security


Namespace UI_Support
    Public Class SegurancaToken
        Inherits SoapFilter
        Public Overrides Function ProcessMessage(ByVal envelope As SoapEnvelope) As SoapFilterResult
            ' Remove all WS-Addressing and WS-Security header info
            'envelope.Header.RemoveAll();
            ' RemoveTag(envelope.DocumentElement, "wsa:Action");

            'RemoveTag(envelope.DocumentElement, "wsa:MessageID");
            'RemoveTag(envelope.DocumentElement, "wsa:To");
            'Create the XML.. DO NOT append it to the passed doc.

            'creating the <wsse:Security> element in the outgoing message

            Dim securityNode As XmlNode = envelope.CreateNode(XmlNodeType.Element, "wsse:Security", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")

            Dim securityAttr As XmlAttribute = envelope.CreateAttribute("soap:mustUnderstand")



            securityAttr.Value = "1"
            securityNode.Attributes.Append(securityAttr)


            'XmlElement SecurityElement = securityNode as XmlElement;

            'SecurityElement.SetAttribute("soap:mustUnderstand", "1");

            'creating the <wsse:usernameToken> element


            Dim usernameTokenNode As XmlNode = envelope.CreateNode(XmlNodeType.Element, "wsse:UsernameToken", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")

            Dim userElement As XmlElement = TryCast(usernameTokenNode, XmlElement)

            userElement.SetAttribute("xmlns:wsu", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd")

            'creating the <wsse:Username> element

            Dim userNameNode As XmlNode = envelope.CreateNode(XmlNodeType.Element, "wsse:Username", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")

            'userNameNode.InnerXml = "xrm"
            userNameNode.InnerXml = "integracao.sfi"
            'IniFile ini = new IniFile("data.ini");//ini["Usuario", "Usuario"].ToString();//


            'creating the <wsse:password> element

            Dim pwdNode As XmlNode = envelope.CreateNode(XmlNodeType.Element, "wsse:Password", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")

            Dim pwdElement As XmlElement = TryCast(pwdNode, XmlElement)

            pwdElement.SetAttribute("Type", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText")

            'pwdNode.InnerXml = "J!xu8@Uy"
            pwdNode.InnerXml = "inicio"

            '"wpsadmin";
            usernameTokenNode.AppendChild(userNameNode)

            usernameTokenNode.AppendChild(pwdNode)

            securityNode.AppendChild(usernameTokenNode)

            envelope.ImportNode(securityNode, True)

            Dim node As XmlNode = envelope.Header

            node.AppendChild(securityNode)

            'removing Addressing headers from the outgoing request

            Dim actionNode As XmlNode = envelope.Header("wsa:Action")

            envelope.Header.RemoveChild(actionNode)

            Dim messageNode As XmlNode = envelope.Header("wsa:MessageID")

            envelope.Header.RemoveChild(messageNode)

            Dim replyToNode As XmlNode = envelope.Header("wsa:ReplyTo")

            envelope.Header.RemoveChild(replyToNode)

            Dim toNode As XmlNode = envelope.Header("wsa:To")

            envelope.Header.RemoveChild(toNode)


            Return SoapFilterResult.[Continue]
        End Function
        Private Sub RemoveTag(ByVal XE As System.Xml.XmlElement, ByVal TagName As String)
            For Each N As XmlNode In XE
                If (N.ChildNodes.Count > 0) Then
                    RemoveTag(DirectCast(N, XmlElement), TagName)
                End If
                If (N.Name = TagName) Then
                    XE.RemoveChild(N)
                End If
            Next
        End Sub
    End Class

    Public Class MyAssertion
        Inherits PolicyAssertion
        Public Overrides Function CreateClientInputFilter(ByVal context As FilterCreationContext) As SoapFilter
            'UsernameToken token = new UsernameToken("wpsadmin", "wpsadmin", PasswordOption.SendPlainText);

            Return Nothing
        End Function

        Public Overrides Function CreateClientOutputFilter(ByVal context As FilterCreationContext) As SoapFilter
            Return New SegurancaToken()
        End Function

        Public Overrides Function CreateServiceInputFilter(ByVal context As FilterCreationContext) As SoapFilter
            Return Nothing
        End Function

        Public Overrides Function CreateServiceOutputFilter(ByVal context As FilterCreationContext) As SoapFilter
            Return Nothing
        End Function
    End Class

End Namespace