Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Net

''' <summary>
''' Summary description for Proxer
''' </summary>
Public Class clsProxyPFC
    Public Sub New()
    End Sub
    Public Shared Function returnProxy() As WebProxy
        '192.168.20.14 
        '10.0.4.248:9080
        Dim proxyServer As New WebProxy("ISS001LXTWS01:9080")
        Dim proxy As New NetworkCredential("integracao.sfi", "inicio", "AP2HA116:9080")
        proxyServer.Credentials = proxy

        Return proxyServer
    End Function

End Class