﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Drawing
Imports System.Windows.Forms.VisualStyles

''' <summary>
''' Custom Componente ComboBox com checkbox
''' Pode ser carregada manualmente (ComboBoxData) ou via (DataTable pelo DataSource)
''' </summary>
''' <remarks></remarks>
Public Class ComboBoxCheck
    Inherits ComboBox

    Dim dataSourceInUpdate As Boolean = False

#Region "DataSource"

    Private _valueCheck As String
    Private _valueSepator As String = ", "

    ''' <summary>
    ''' Propriedade com o nome da coluna check (boolean))
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ValueCheck() As String
        Get
            Return _valueCheck
        End Get
        Set(ByVal value As String)
            _valueCheck = value
        End Set
    End Property

    ''' <summary>
    ''' Propriedade com o nome da coluna value (ex. id, codigo)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ValueSepator() As String
        Get
            Return _valueSepator
        End Get
        Set(ByVal value As String)
            _valueSepator = value
        End Set
    End Property

#End Region

    Public Event Checkchanged As EventHandler

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        Me.DrawMode = Windows.Forms.DrawMode.OwnerDrawFixed
    End Sub

    Public ReadOnly Property CheckedText() As String
        Get
            Dim texto As String = String.Empty

            For Each row As DataRow In Me.CheckedItems
                texto &= row(IIf(String.IsNullOrWhiteSpace(DisplayMember), "Data", DisplayMember)) & ValueSepator
            Next

            If texto.Length >= ValueSepator.Length Then
                texto = texto.Substring(0, texto.Length - ValueSepator.Length)
            End If

            Return texto
        End Get
    End Property

    ''' <summary>
    ''' Recupera os itens selecionados (checked))
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property CheckedItems() As DataRowCollection
        Get
            Dim rowViewItens As List(Of DataRowView) = CheckedRowItems()
            Dim dt As New DataTable
            Dim valueMemberTmp As String = String.Empty
            Dim valueCheckedTmp As Boolean = False

            If (rowViewItens IsNot Nothing AndAlso rowViewItens.Count > 0) Then
                dt.Columns.Add(DisplayMember, GetType(String))
                dt.Columns.Add(ValueMember, GetType(String))
                dt.Columns.Add(ValueCheck, GetType(Boolean))
                For Each item As DataRowView In rowViewItens
                    If (Not String.IsNullOrWhiteSpace(ValueMember)) Then
                        valueMemberTmp = item(ValueMember).ToString()
                    End If

                    If item(ValueCheck) Is DBNull.Value Then
                        valueCheckedTmp = False
                    Else
                        valueCheckedTmp = item(ValueCheck)
                    End If

                    dt.Rows.Add(item(DisplayMember).ToString(), valueMemberTmp, valueCheckedTmp)
                Next
            End If

            Return dt.Rows
        End Get
    End Property

    ''' <summary>
    ''' Recupera os itens selecionados (checked) - DataSource
    ''' Utilize preferencialmente o <see cref="CheckItems">CheckItems</see>
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private ReadOnly Property CheckedRowItems As List(Of DataRowView)
        Get
            Dim newItems As List(Of DataRowView) = New List(Of DataRowView)()

            For Each item As Object In Items

                If TypeOf item Is DataRowView AndAlso Not String.IsNullOrWhiteSpace(ValueCheck) Then
                    Dim row As DataRowView = TryCast(item, DataRowView)
                    If (row(ValueCheck) IsNot DBNull.Value AndAlso CBool(row(ValueCheck))) Then
                        newItems.Add(row)
                    End If
                End If
            Next

            Return newItems
        End Get
    End Property

    Protected Overrides Sub OnSelectedIndexChanged(ByVal e As EventArgs)
        'apos update do datasource o evento e disparado 1x
        'ou se o combo esta aberto (permitindo digitar a letra para buscar sem marcar o item)
        If dataSourceInUpdate OrElse Me.DroppedDown Then
            dataSourceInUpdate = False
            Return
        End If

        MyBase.OnSelectedIndexChanged(e)

        If TypeOf (SelectedItem) Is DataRowView AndAlso Not String.IsNullOrWhiteSpace(ValueCheck) Then
            Dim row As DataRowView = CType(SelectedItem, DataRowView)
            If row(ValueCheck) Is DBNull.Value Then row(ValueCheck) = False
            row(ValueCheck) = Not row(ValueCheck)
        End If

        'tem que definir -1 para conseguir escrever todos itens selecionados na combo
        Me.SelectedIndex = -1
        OrdenarItems()
    End Sub

    ''' <summary>
    ''' Realiza o "desenho" da combobox (adiciona o texto com checkbox)"
    ''' </summary>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Overrides Sub OnDrawItem(ByVal e As DrawItemEventArgs)
        ' se for index = -1 ou (combo "fechada" e sem itens marcado)
        If e.Index = -1 OrElse Not Me.DroppedDown Then
            'escreve todos items selecionado na combo
            e.Graphics.DrawString(CheckedText(), Me.Font, Brushes.Black, New Point(e.Bounds.X, e.Bounds.Y))
            Return
        End If

        If TypeOf (Items(e.Index)) Is DataRowView AndAlso Not String.IsNullOrWhiteSpace(Me.DisplayMember) Then
            If (Not String.IsNullOrWhiteSpace(ValueCheck)) Then
                'checkbox
                CheckBoxRenderer.RenderMatchingApplicationState = True
                Dim textBounds As System.Drawing.Rectangle = e.Bounds
                textBounds.X += 15 '+15 para nao escrever o texto em cima do componente checkbox
                CheckBoxRenderer.DrawCheckBox(e.Graphics, New Point(e.Bounds.X, e.Bounds.Y), textBounds,
                    Items(e.Index)(DisplayMember).ToString(),
                    Me.Font, TextFormatFlags.Default, False,
                    If(Items(e.Index)(ValueCheck) IsNot DBNull.Value AndAlso CBool(Items(e.Index)(ValueCheck)), CheckBoxState.CheckedNormal, CheckBoxState.UncheckedNormal))
            Else
                'escreve apenas o texto (padrao da combobox)
                e.Graphics.DrawString(Items(e.Index)(DisplayMember).ToString(), Me.Font, Brushes.Black, New Point(e.Bounds.X, e.Bounds.Y))
            End If
            Return
        Else
            'escreve apenas o texto (padrao da combobox)
            e.Graphics.DrawString(Items(e.Index).ToString(), Me.Font, Brushes.Black, New Point(e.Bounds.X, e.Bounds.Y))
            Return
        End If

        MyBase.OnDrawItem(e)
    End Sub

    ''' <summary>
    ''' Ao exibir o DropDown da combo, calcula o tamanho a ser exibido
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ComboBoxCheck_DropDown(sender As System.Object, e As System.EventArgs) Handles MyBase.DropDown
        Me.DropDownHeight = Me.MaxDropDownItems * Me.ItemHeight
    End Sub

    Private Sub ComboBoxCheck_DataSourceChanged(sender As System.Object, e As System.EventArgs) Handles MyBase.DataSourceChanged
        dataSourceInUpdate = True
        Dim existColumnCheck As Boolean = False

        If (DataSource Is Nothing) Then Return

        'se vazia atribui um valor default
        If (String.IsNullOrWhiteSpace(ValueCheck)) Then ValueCheck = "colCheck"

        'verifica se tem a coluna check
        If (TypeOf (DataSource) Is DataTable) Then
            Dim dt As DataTable = TryCast(DataSource, DataTable)
            existColumnCheck = dt.Columns.Count > 0 AndAlso dt.Columns.Contains(ValueCheck)

            'se nao existir criamos uma
            If (Not existColumnCheck) Then
                dt.Columns.Add(ValueCheck, GetType(Boolean))
                existColumnCheck = True
            End If
        End If
    End Sub

    ''' <summary>
    ''' Ordena os itens da combo
    ''' Valores com check primeiro, seguido por ordem alfabetica
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OrdenarItems()
        If (Me.DataSource Is Nothing) Then Return

        Dim dt As DataTable = CType(Me.DataSource, DataTable)
        Dim dt2 As New DataTable
        'ordena por selecionados (desc = true/false), seguido pelo nome exibido
        Dim rows As DataRow() = dt.Select("", "" & ValueCheck & " ASC, " & DisplayMember & " ASC ")
        If (rows.Length > 0) Then
            dt2 = rows.CopyToDataTable()
            Me.DataSource = dt2
            Me.Refresh()
        End If

    End Sub

End Class