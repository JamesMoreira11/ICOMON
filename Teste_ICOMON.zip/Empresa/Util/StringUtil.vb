﻿Imports System.Text

Public Class StringUtil

    ''' <summary>
    ''' Retira acentuações, espaços duplos e espaços à esquerda e à direita
    ''' </summary>
    ''' <param name="input"></param>
    ''' <returns></returns>
    Public Function NormalizeText(ByVal input As String) As String

        Dim normalizedString As String = input.Normalize(NormalizationForm.FormD)

        Dim stringBuilder As New StringBuilder()

        Dim c As Char

        Dim i As Integer = 0

        For i = 0 To normalizedString.Length - 1

            c = normalizedString(i)

            If Globalization.CharUnicodeInfo.GetUnicodeCategory(c) <> Globalization.UnicodeCategory.NonSpacingMark Then

                stringBuilder.Append(c)

            End If

        Next

        Dim text As String = stringBuilder.ToString()

        While text.Contains(Space(2))

            text = text.Replace(Space(2), Space(1))

        End While

        Return text.Trim()

    End Function

End Class