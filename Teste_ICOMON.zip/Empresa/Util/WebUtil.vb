﻿Imports System.Net

Public Class WebUtil

    Public Function CheckWebServiceOnline(url As String)

        Try

            Dim webRequest = Net.WebRequest.Create(url)

            Dim webResponse = webRequest.GetResponse()

            Return True

        Catch ex As Exception

            Return False

        End Try

    End Function

End Class