﻿Imports System.Text

Public Class DataGridViewUtil

    Public Sub Clear(inputDataGridView As DataGridView)

        If Not inputDataGridView.DataSource Is Nothing Then

            Call CType(inputDataGridView.DataSource, DataTable).Rows.Clear()

        Else

            inputDataGridView.Rows.Clear()

        End If

        inputDataGridView.ClearSelection()

        inputDataGridView.CurrentCell = Nothing

    End Sub

    Public Function Count(inputDataGridView As DataGridView) As Integer

        Return inputDataGridView.Rows.Count

    End Function

    Public Function Find(inputDataGridView As DataGridView, colIndex As Integer, findString As String) As Boolean

        Dim rows As DataGridViewRowCollection = inputDataGridView.Rows

        For Each row As DataGridViewRow In rows

            If GetStringValue(row, colIndex).Equals(findString) Then

                Return True

                Exit For

            End If

        Next

        Return False

    End Function

    Public Function GetColsCount(inputDataGridView As DataGridView) As Integer

        Return inputDataGridView.Columns.Count

    End Function

    Public Function GetCountRowsSelected(inputDataGridView As DataGridView) As Integer

        Return inputDataGridView.SelectedRows.Count

    End Function

    Public Function GetRows(inputDataGridView As DataGridView) As DataGridViewRowCollection

        Return inputDataGridView.Rows

    End Function

    Public Function GetSelectedRowsIndex(inputDataGridView As DataGridView) As List(Of Integer)

        Dim selectedRows = inputDataGridView.SelectedRows

        Dim list As New List(Of Integer)

        For Each row As DataGridViewRow In selectedRows

            list.Add(row.Index)

        Next row

        Return list

    End Function

    Public Function GetSelectedRow(inputDataGridView As DataGridView) As DataGridViewRow

        Return inputDataGridView.SelectedRows(0)

    End Function

    Public Function GetSelectedRows(inputDataGridView As DataGridView) As DataGridViewSelectedRowCollection

        Return inputDataGridView.SelectedRows

    End Function

    Public Sub DeleteRow(inputDataGridView As DataGridView, rowIndex As Integer)

        inputDataGridView.Rows.Remove(inputDataGridView.Rows(rowIndex))

    End Sub

    Public Sub DeleteSelectedRows(inputDataGridView As DataGridView)

        Dim list As List(Of Integer) = GetSelectedRowsIndex(inputDataGridView)

        For Each index As Integer In list

            DeleteRow(inputDataGridView, index)

        Next

    End Sub

    Public Function GetDateValue(inputDataGridViewRow As DataGridViewRow, colIndex As Integer) As Date

        Return CType(inputDataGridViewRow.Cells(colIndex).Value.ToString(), Date)

    End Function

    Public Function GetDecimalValue(inputDataGridViewRow As DataGridViewRow, colIndex As Integer) As Decimal

        Return Decimal.Parse(inputDataGridViewRow.Cells(colIndex).Value.ToString())

    End Function

    Public Function GetIntegerValue(inputDataGridViewRow As DataGridViewRow, colIndex As Integer) As Integer

        Return Integer.Parse(inputDataGridViewRow.Cells(colIndex).Value.ToString())

    End Function

    Public Function GetSelectedRowsValues(inputDataGridView As DataGridView, Optional printHeader As Boolean = False, Optional splitChar As Char = vbTab) As List(Of String)

        Dim SelectedRows = GetSelectedRows(inputDataGridView)

        Dim colsIndex = inputDataGridView.ColumnCount - 1

        Dim result As New List(Of String)

        Dim i As Integer

        Dim text As New StringBuilder

        If printHeader Then

            For i = 0 To colsIndex

                text.Append(String.Format("{0}{1}", inputDataGridView.Columns(i).HeaderText, splitChar))

            Next

            result.Add(text.ToString())

        End If

        For Each row As DataGridViewRow In SelectedRows

            text.Clear()

            For i = 0 To colsIndex

                text.Append(String.Format("{0}{1}", IIf(Not row.Cells(i).Value Is Nothing, row.Cells(i).Value.ToString(), String.Empty), splitChar))

            Next

            result.Add(text.ToString())

        Next

        Return result

    End Function

    Public Function GetMaxRowIndex(inputDataGridView As DataGridView) As Integer

        Return inputDataGridView.Rows.Count - 1

    End Function

    Public Function GetRow(inputDataGridView As DataGridView, rowIndex As Integer) As DataGridViewRow

        Return inputDataGridView.Rows(rowIndex)

    End Function

    Public Function GetRowsValues(inputDataGridView As DataGridView, Optional printHeader As Boolean = False, Optional splitChar As Char = vbTab) As List(Of String)

        Dim rows = inputDataGridView.Rows

        Dim colsIndex = inputDataGridView.ColumnCount - 1

        Dim result As New List(Of String)

        Dim i As Integer

        Dim text As New StringBuilder

        If printHeader Then

            For i = 0 To colsIndex

                text.Append(String.Format("{0}{1}", inputDataGridView.Columns(i).HeaderText, splitChar))

            Next

            result.Add(text.ToString())

        End If

        For Each row As DataGridViewRow In rows

            text.Clear()

            For i = 0 To colsIndex

                text.Append(String.Format("{0}{1}", IIf(Not row.Cells(i).Value Is Nothing, row.Cells(i).Value.ToString(), String.Empty), splitChar))

            Next

            result.Add(text.ToString())

        Next

        Return result

    End Function

    Public Function GetStringValue(inputDataGridViewRow As DataGridViewRow, colIndex As Integer) As String

        If inputDataGridViewRow.Cells(colIndex).Value Is Nothing Then

            Return String.Empty

        End If

        Return inputDataGridViewRow.Cells(colIndex).Value.ToString()

    End Function

    Public Function GetValue(inputDataGridView As DataGridView, rowIndex As Integer, colIndex As Integer) As String

        Return inputDataGridView.Rows(rowIndex).Cells(colIndex).Value.ToString()

    End Function

    Public Function HasRowSelected(inputDataGridView As DataGridView) As Boolean

        Return IIf(inputDataGridView.SelectedRows.Count() > 0, True, False)

    End Function

    Public Sub SetValue(inputDataGridView As DataGridView, rowIndex As Integer, colIndex As Integer, newValue As String)

        inputDataGridView.Rows(rowIndex).Cells(colIndex).Value = newValue

    End Sub

    Public Sub SetValue(inputDataGridViewRow As DataGridViewRow, colIndex As Integer, newValue As String)

        inputDataGridViewRow.Cells(colIndex).Value = newValue

    End Sub

    Public Sub SetVisible(inputDataGridViewRow As DataGridViewRow, visible As Boolean)

        inputDataGridViewRow.Visible = visible

    End Sub

    Public Sub Unselect(inputDataGridView As DataGridView)

        inputDataGridView.ClearSelection()

        inputDataGridView.CurrentCell = Nothing

    End Sub

End Class