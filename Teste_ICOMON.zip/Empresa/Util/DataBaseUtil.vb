﻿Imports System.Reflection

Public Class DataBaseUtil

    Public Shared Function ConvertDataTableToList(Of T)(table As DataTable) As List(Of T)

        If table Is Nothing Or table.Rows.Count.Equals(0) Then

            Return Nothing

        End If

        Dim lines As New List(Of DataRow)()

        For Each row As DataRow In table.Rows

            lines.Add(row)

        Next

        Return ConvertDataRowToList(Of T)(lines)

    End Function

    Private Shared Function ConvertDataRowToList(Of T)(linhas As List(Of DataRow)) As List(Of T)

        Dim list As List(Of T) = Nothing

        If linhas IsNot Nothing Then

            list = New List(Of T)()

            For Each linha As DataRow In linhas

                Dim item As T = CriarItem(Of T)(linha)

                list.Add(item)

            Next

        End If

        Return list

    End Function

    Private Shared Function CriarItem(Of T)(row As DataRow) As T

        If row Is Nothing Then

            Return Nothing

        End If

        'converte um DataRow para um objeto T
        Dim nomeDaColuna As String

        Dim objeto As T = Nothing

        objeto = Activator.CreateInstance(Of T)()

        For Each coluna As DataColumn In row.Table.Columns

            nomeDaColuna = coluna.ColumnName

            ' Pega a propriedade com a mesma coluna
            Dim objType As Type = objeto.GetType()

            Dim prop As PropertyInfo = objType.GetProperty(nomeDaColuna, BindingFlags.IgnoreCase + BindingFlags.Public + BindingFlags.Instance)

            Try

                'Pega o valor da coluna
                Dim value As Object

                value = If((row(nomeDaColuna).[GetType]() = GetType(DBNull)), Nothing, row(nomeDaColuna))

                'Define o valor da propriedade
                prop.SetValue(objeto, value, Nothing)

            Catch
                Throw
            End Try
        Next

        Return objeto

    End Function

    Public Function ConvertNullToString([object] As Object) As String

        If [object] Is Nothing Then

            Return String.Empty

        Else

            Return [object].ToString()

        End If

    End Function

    Public Function GetNullIfEmpty([object] As Object) As String

        If [object] Is Nothing Then

            Return "NULL"

        End If

        If TypeOf [object] Is Date Then

            Dim data As Date

            data = Date.Parse([object].ToString())

            If data.Equals(Date.MinValue) Then

                Return "NULL"

            Else

                Return "TO_DATE('" & data.ToString("dd/MM/yyyy HH:mm:ss") & "', 'dd/mm/yyyy hh24:mi:ss')"

            End If

        ElseIf TypeOf [object] Is Integer Or TypeOf [object] Is Decimal Then

            If [object] <= 0 Then

                Return "NULL"

            Else

                Return [object].ToString().Replace(",", ".")

            End If

        ElseIf TypeOf [object] Is String Then

            If String.IsNullOrWhiteSpace([object].ToString()) Then

                Return "NULL"

            Else

                Return "'" & [object].ToString() & "'"

            End If

        Else

            Throw New Exception("Tipo inválido")

        End If

    End Function

    Public Function DataTableOrderBy(dataTable As DataTable, columnName As String, Optional descending As Boolean = False) As DataTable

        Dim dataView As DataView = dataTable.DefaultView

        If descending Then

            dataView.Sort = columnName & " DESC"

        Else

            dataView.Sort = columnName

        End If

        Return dataView.ToTable()

    End Function

    Public Function DataTableOrderBy(dataTable As DataTable, columnIndex As Short, Optional descending As Boolean = False) As DataTable

        Dim dataView As DataView = dataTable.DefaultView

        If descending Then

            dataView.Sort = dataTable.Columns(columnIndex).ColumnName & " DESC"

        Else

            dataView.Sort = dataTable.Columns(columnIndex).ColumnName

        End If

        Return dataView.ToTable()

    End Function

    Public Function DataTableFind(dataTable As DataTable, columnName As String, findValue As String) As DataTable

        Return dataTable.Select(columnName & "='" & findValue & "'").CopyToDataTable()

    End Function

    Public Function DataTableContains(dataTable As DataTable, columnName As String, findValue As String) As DataTable

        Return dataTable.Select(columnName & "='%" & findValue & "%'").CopyToDataTable()

    End Function

    Public Function GetValue(dataTable As DataTable, Optional rowIndex As Integer = 0, Optional columnIndex As Short = 0) As Object

        If dataTable.Rows.Equals(0) Then

            Return vbNull

        End If

        Return dataTable.Rows(rowIndex)(columnIndex)

    End Function

    Public Function GetValue(dataTable As DataTable, columnName As String, Optional rowIndex As Integer = 0) As Object

        If dataTable.Rows.Equals(0) Then

            Return vbNull

        End If

        Return dataTable.Rows(rowIndex)(columnName)

    End Function

End Class