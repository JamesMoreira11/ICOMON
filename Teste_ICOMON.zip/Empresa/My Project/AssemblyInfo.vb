﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("SFI - Sistema de Faturamento Intermédica")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Intermédica Sistema de Saúde")> 
<Assembly: AssemblyProduct("SFI - Sistema de Faturamento Intermédica")> 
<Assembly: AssemblyCopyright("Copyright © Intermédica Sistema de Saúde 2015")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("4ec3161b-b2c8-4726-bf18-0a7fd4f080af")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
<Assembly: AssemblyVersion("4.0.*")> 
