﻿Imports System.Data.OracleClient
Imports System.Data.OleDb
Public Module Interfaces
    Public frmMDI As New MDIPrincipal

#Region "Enuns"
    'Enumeração para ordenar grid
    Public Enum direcaoOrdem
        asc = 1
        desc = 2
    End Enum

    Public Enum TipoEndereco
        Cobranca = 1
        Faturamento = 2
        Etiqueta = 3
        Comercial = 4
        Residencial = 5
        MalaDireta = 6
        RN412 = 7
    End Enum

    Public Enum ETipoContrato
        Pj = 1
        Pme = 8
        Pf = 17
        Dap = 15
        Licitacao = 34
    End Enum

    Public Enum ETipoArquivo
        Completo = 0
        Simplificado = 1
    End Enum
#End Region


    'Variaveis de Usuário e Senha Oracle
    Public psLogin As String
    Public psSenha As String
    Public paCodPerfil() As Int16
    Public psNomePerfil As String
    Public psNomUsuario As String
	Public psEmailUsuario As String
    Public psServidor As String
    Public piCodUnidade As Int16
    Public psNomUnidade As String
    Public psCodFilial As String
    Public psCodPesquisa As String
    Public psDescPesquisa As String
    Public psCodGrupoContrato As String
    Public psNomeGrupoContrato As String
    Public psTipPessoa As String
    Public lCodContrato As Long
    Public lCodSubContrato As Long
    Public pbAlterouConexao As Boolean
    Public pDatEmissao As Date
    Public psSubcontrato As Long
    Public bSplash As Boolean = True
    Public bSair As Boolean

    Public bNFSEHomologacao As Boolean = True

    Public sMsgNota As String = ""
    Public sNota As String = ""
    Public sMsgErroNotas = ""
    Public sMsgRPSNaoEncontrado = ""

    'Conexão
    Public oConn As OracleConnection
    Public oTrans As OracleClient.OracleTransaction

    '********* Sistemas ****************************
    Public Const cCodSistema As Int16 = 1
    Public Const cCodMnuCadastro As Integer = 1
    Public Const cCodMnuReajuste As Integer = 2
    Public Const cCodMnuFaturamento As Integer = 3
    Public Const cCodMnuFinanceiro As Integer = 4
    Public Const cCodMnuContabilidade As Integer = 7
    Public Const cCodMnuRelatorios As Integer = 5
    Public Const cCodMnuSistema As Integer = 6

    Public Const cAcaoAprovar As String = "APROVAR"
    Public Const cAcaoReprovar As String = "REPROVAR"
    Public Const cAcaoAguardar As String = "AGUARDAR"
    Public Const cAcaoProximo As String = "PROXIMO"

    Public Const cAcaoImprimir As String = "IMPRIMIR"
    Public Const cAcaoDarBaixa As String = "GERARELACAO"
    Public Const cAcaoInconsistencia As String = "SELECIONAR"
    Public Const cAcaoVisualizarImpressao As String = "VISUALIZARIMPRESSAO"
    Public Const cAcaoExportar As String = "EXPORTAR"
    Public Const cAcaoSair As String = "SAIR"

    Public Const cAcaoEncaminhar As String = "ENCAMINHAR"
    Public Const cAcaoEncerrar As String = "ENCERRAR"

    Public Const cMnuCadastro As String = "ID_Cadastro"
    Public Const cMnuReajuste As String = "ID_Reajuste"
    Public Const cMnuFaturamento As String = "ID_Faturamento"
    Public Const cMnuFinanceiro As String = "ID_Financeiro"
    Public Const cMnuRelatorios As String = "ID_Relatorios"
    Public Const cMnuFerramentas As String = "Ferramentas"
    Public Const cMnuSistema As String = "ID_Sistema"

    '*** Cores de Tela
    Public Const corDesabilitado As Long = &HE0E0E0
    Public Const corDesabilitadoOutros As Long = &H8000000F
    Public Const corHabilitado As Long = &H80000005
    Public Const corObrigatorio As Long = &HC0FFFF    '&HC0FFFF
    Public Const corNObrigatorio As Long = &HFFFF00 '&HFFFFC0       '&HC0FFFF
    Public Const corHabilitadoOutros As Long = &H8000000F

    Public sAcaoTela As String
    Public sModoTela As String
    Public Const cModoLiberando As String = "LIBERANDO"
    Public Const cModoAlteracao As String = "ALTERACAO"
    Public Const cModoPesquisa As String = "PESQUISAR"
    Public Const cModoInclusao As String = "INCLUSAO"
    Public Const cModoVisualizacao As String = "VISUALIZACAO"
    Public Const cModoExcluir As String = "EXCLUIR"

    Public Const cAcaoCancelar As String = "CANCELAR"
    Public Const cAcaoLimpar As String = "LIMPAR"
    Public Const cAcaoPesquisar As String = "PESQUISAR"
    Public Const cAcaoIncluir As String = "INCLUIR"
    Public Const cAcaoExcluir As String = "EXCLUIR"
    Public Const cAcaoAtualizar As String = "ATUALIZAR"
    Public Const cAcaoProcessar As String = "PROCESSAR"
    Public Const cAcaoMaximizar As String = "MAXIMIZAR"
    Public Const cAcaoOrdenar As String = "SORT"
    Public Const cAcaoSelecionar As String = "SELECIONAR"
    Public Const cAcaoGeraRelacao As String = "GERALOTE"
    Public Const cAcaoGeraCalculo As String = "GERACALCULO"


    Public oCB03_1 As FRM_CB03_1

    Public oConectar As frmConectar

    'Vencimento do certificado 21-02-2021'
    Public Const NumeroCertificado As String = "464D20022070B79A"

    Public Const NumeroCertificadoSBC As String = "464D19102340B836"

    Public Const NumeroCertificadoSorocaba As String = "32303131303330313230343130343230"
    Public Const NumeroCertificadoUberlandia As String = "32303133303531373137343434363631"

    Public bVigencia_Senha As Boolean  'Controle de vigência de senha do usuário.

    ' Extração Hyperion
    Public Const StatusExtracaoIniciada As Integer = 1
    Public Const StatusExtracaoSucesso As Integer = 2
    Public Const StatusExtracaoErro As Integer = 3

    'Tipo Lançamento
    Public Const cTpLancAM_6000 As Integer = 57
    Public Const cTpLancCopart_6000 As Integer = 32
    '[GINL-4295] PLANO FUNCIONARIO
    Public Const cTpLancAM_7000 As Integer = 91
    Public Const cTpLancCopart_7000 As Integer = 90

    'Contrato Funcionários
    Public Const cContratoFatFunc As Integer = 9999994

    Public Const consPerfilAlteraVigenciaContrato As Integer = 706

    Public Const consFilialSaoPaulo As Integer = 41

    'Perfil que podem utilizar o repasse Odonto
    Public Const consPerfilRepasseOdonto As Integer = 705

    'Perfis que podem utilizar o PPCNG
    Public Const consPerfilPPCNGUser As Integer = 713
    Public Const consPerfilPPCNGAdmin As Integer = 714
End Module

