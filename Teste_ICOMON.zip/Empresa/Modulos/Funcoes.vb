﻿Imports System.Configuration
Imports System.Data.OracleClient
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports System.Security.Cryptography
Imports System.Text
Imports System.Xml
Imports System.Data.OleDb
Imports System.Data.Odbc
Imports Newtonsoft.Json

Public Module mlPublic
    '*** Conversao Numero P/ Descricao
    Public M_tTerceiros(10) As String
    Public M_tSegundos(10) As String
    Public M_tPrimeiros(10) As String
    Public M_tDezenas(10) As String
    Public mostraMensagem As Boolean = True
    Dim Dirs As New List(Of String)

    Public Function Path() As String
        Dim sPath As String = Application.StartupPath
        If sPath.Substring(sPath.Length - 1, 1) <> "\" Then
            sPath += "\"
        End If
        Return sPath
    End Function

    Public Sub RemoveArquivos(ByVal Path As String, ByVal Extensao As String)
        ' Exclui os Arquivos do Caminho $PATH
        Dim file As String

        DirSearch(Path)
        ' Apaga os arquivos do dir
        For Each file In System.IO.Directory.GetFiles(Path)
            Try
                If file.IndexOf("." & Extensao) > -1 Then
                    System.IO.File.Delete(file)
                End If
            Catch ex As Exception
                'caso não consiga apagar
                'msgaviso("Não foi Possivel apagar o arquivo " & file)
            End Try
        Next
        ' Apaga os Arquivos dos SubDirs
        For d As Int32 = Dirs.Count - 1 To 0 Step -1
            For Each file In System.IO.Directory.GetFiles(Dirs(d))
                Try
                    If file.IndexOf("." & Extensao) > -1 Then
                        System.IO.File.Delete(file)
                    End If
                Catch ex As Exception
                    'caso não consiga apagar
                End Try
            Next
        Next
    End Sub

    Public Function Remove_BLOB(ByVal pUnidadeNegocio As String, ByVal pFilial As String, ByVal pNotaFiscal As String) As Boolean

        Try

            'Gravar arquivo no Banco 
            'Instancia o Objeto BLob
            Dim o_ArquivoBlob As New Blob.Biblioteca
            'Gravação do Registro
            'CodSistema – Código do Sistema
            'CodDocumento – Código do Tipo do Documento
            'NumReferencia – Número da Refência
            'Arquivo – Caminho do Arquivo a Ser Gravado

            'Monta Referencia
            Dim referencia As String
            'Cod Unidade Negocio 1 posição 
            referencia = pUnidadeNegocio
            Dim filial As String = pFilial
            'Cod filial 3 posições com zero a esquerda
            referencia += filial.PadLeft(3, "0")
            Dim nf As String = pNotaFiscal
            'Notafiscal de 6 posições
            referencia += nf.PadLeft(6, "0")
            Dim b_LOCALIZAR_ARQUIVO As Boolean
            b_LOCALIZAR_ARQUIVO = o_ArquivoBlob.LocalizarArquivo(1, 1, referencia, oConn)
            If b_LOCALIZAR_ARQUIVO = False Then
                Return True
            Else
                'Exclusão do Registro
                'CodSistema – Código do Sistema
                'CodDocumento – Código do Tipo do Documento
                'NumReferencia – Número da Refência
                Dim b_EXCLUIR_ARQUIVO As Boolean
                b_EXCLUIR_ARQUIVO = o_ArquivoBlob.ExcluirArquivo(1, 1, referencia, oConn)
                Return b_EXCLUIR_ARQUIVO
            End If

        Catch ex As Exception
            Return False
        End Try

    End Function

    Private Sub DirSearch(ByVal Path As String)
        Dim SDirs As String
        Dim Dir As String

        For Each Dir In System.IO.Directory.GetDirectories(Path)
            Dirs.Add(Dir)
            For Each SDirs In System.IO.Directory.GetDirectories(Dir)
                Dirs.Add(SDirs)
                DirSearch(SDirs)
            Next
        Next
    End Sub

    Public Function GerarSHA1(ByVal input As String) As String
        Dim sstr As String = ""
        Using alg As New SHA1Managed
            Dim msg As Byte() = Encoding.Default.GetBytes(input)
            Dim hash As Byte() = alg.ComputeHash(msg)

            For i As Integer = 0 To hash.Length - 1
                sstr += (hash(i).ToString("x2"))
            Next
        End Using

        Return sstr
    End Function

    Function getSHA1Hash_Byte(ByVal strToHash As String) As String
        Dim sha1Obj As New Security.Cryptography.SHA1CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strToHash)

        bytesToHash = sha1Obj.ComputeHash(bytesToHash)

        Dim strResult As String = ""

        strResult = Convert.ToBase64String(bytesToHash)

        Return strResult
    End Function

    Public Function ProcuraPerfil(ByVal CodPerfil As Int16) As Boolean
        For x As Int16 = 0 To paCodPerfil.GetUpperBound(0)
            If paCodPerfil(x) = CodPerfil Then
                Return True
            End If
        Next

        Return False
    End Function

    Public Function ProcuraPerfilUnidadeNegocio(ByVal CodPerfil As Int16) As Boolean

        Dim dt As DataTable
        Dim sSQL As String = String.Empty

        Return True

    End Function

    Public Function QuebraString(ByVal sString As String, ByVal iQtdeCaracter As Int16) As String()
        Dim aArray(0) As String
        Dim iPos As Int32
        sString = Replace(sString, Chr(13), " ")
        If sString.Length <= iQtdeCaracter Then
            ReDim aArray(1)
            aArray(0) = sString
        Else
            Do While sString.Length > 0
                ReDim Preserve aArray(aArray.GetUpperBound(0) + 1)
                If sString.Length < iQtdeCaracter Then
                    iPos = sString.Length
                Else
                    iPos = iQtdeCaracter
                    Do While True
                        If iPos = 0 Then Exit Do
                        If sString.Substring(iPos - 1, 1) = " " Then Exit Do
                        iPos = iPos - 1
                    Loop
                End If
                If iPos = 0 Then
                    If sString.Length > 0 Then
                        iPos = sString.Length
                    Else
                        Exit Do
                    End If
                End If
                aArray(aArray.GetUpperBound(0) - 1) = sString.Substring(0, iPos).Trim
                If sString.Length > iPos + 1 Then
                    sString = sString.Substring(iPos)
                Else
                    sString = ""
                End If
            Loop
        End If

        ReDim Preserve aArray(aArray.GetUpperBound(0) - 1)
        Return aArray
    End Function

    Public Function QuebraLinha(ByRef sString As String, ByVal iQtdeCaracter As Int16, ByVal sSeparador As String) As String
        Dim sRet As String = ""
        Dim iTotal As Int16 = iQtdeCaracter

        If sString <> "" Then
            If Len(sString) < iTotal Then
                sRet += sString
                sString = ""
            Else
                If Len(sString) >= iTotal Then
                    Dim iAchou As Int16 = iTotal
                    If sSeparador <> "" Then
                        For x As Int16 = iTotal - 1 To 0 Step -1
                            If sString.Substring(x, 1) = "," Then
                                iAchou = x
                                Exit For
                            End If
                        Next
                    End If
                    sRet = sString.Substring(0, iAchou)
                    If sSeparador <> "" Then
                        iAchou += 1
                    End If
                    If Len(sString) > iTotal Then
                        sString = sString.Substring(iAchou)
                    Else
                        sString = ""
                    End If
                Else
                    sRet = sString
                End If
            End If
        End If

        Return sRet

    End Function

    Public Function NomeMes(ByVal Mes As Int16) As String
        Dim aArray() = "JANEIRO,FEVEREIRO,MARCO,ABRIL,MAIO,JUNHO,JULHO,AGOSTO,SETEMBRO,OUTUBRO,NOVEMBRO,DEZEMBRO".Split(",")
        Return aArray(Mes - 1)
    End Function


    Public Function FormataDescricao(ByVal dr As DataRow) As String
        Dim sRet As String = dr("NOM_PLANO") & "-"

        If NVL(dr("TIP_TABELA"), 1) = 1 Then
            'sRet += QuebraLinha(NVL(dr("DSC_LANCAMENTO"), ""), 65)
            sRet += NVL(dr("DSC_LANCAMENTO"), "")
        Else
            If dr("TIP_ASSOCIADO") = 0 Then
                If dr("COD_TAXA") = 1 Then
                    sRet += dr("NOM_TIP_TABELA") & "-TIT.-(" & NVL(dr("NUM_IDADE_INICIO_FAIXA_ETARIA"), "0") & "-" & NVL(dr("NUM_IDADE_FINAL_FAIXA_ETARIA"), "0") & ")"
                Else
                    sRet += "SOBRE TAXA-" & dr("NOM_TIP_TABELA") & "-TIT.-(" & NVL(dr("NUM_IDADE_INICIO_FAIXA_ETARIA"), "0") & "-" & NVL(dr("NUM_IDADE_FINAL_FAIXA_ETARIA"), "0") & ")"
                End If
            ElseIf dr("TIP_ASSOCIADO") = 1 Then
                If dr("COD_TAXA") = 1 Then
                    sRet += dr("NOM_TIP_TABELA") & "-DEP.-(" & NVL(dr("NUM_IDADE_INICIO_FAIXA_ETARIA"), "0") & "-" + NVL(dr("NUM_IDADE_FINAL_FAIXA_ETARIA"), "0") & ")"
                Else
                    sRet += "SOBRE TAXA-" & dr("NOM_TIP_TABELA") & "-DEP.-(" & NVL(dr("NUM_IDADE_INICIO_FAIXA_ETARIA"), "0") & "-" & NVL(dr("NUM_IDADE_FINAL_FAIXA_ETARIA"), "0") & ")"
                End If
            ElseIf dr("TIP_ASSOCIADO") = 2 Then
                If dr("COD_TAXA") = 1 Then
                    sRet += dr("NOM_TIP_TABELA") & "-AGREG.-(" & NVL(dr("NUM_IDADE_INICIO_FAIXA_ETARIA"), "0") & "-" + NVL(dr("NUM_IDADE_FINAL_FAIXA_ETARIA"), "0") & ")"
                Else
                    sRet += "SOBRE TAXA-" & dr("NOM_TIP_TABELA") & "-AGREG.-(" & NVL(dr("NUM_IDADE_INICIO_FAIXA_ETARIA"), "0") & "-" & NVL(dr("NUM_IDADE_FINAL_FAIXA_ETARIA"), "0") & ")"
                End If
            ElseIf dr("TIP_ASSOCIADO") = 9 Then
                sRet += dr("NOM_TIP_TABELA") & "-" & QuebraLinha(dr("DSC_LANCAMENTO"), 65)
            End If
        End If

        Return sRet
    End Function

    Public Function AlinhaString(ByVal sValorInicial As String, ByVal iTamanho As Integer, ByVal iLado As Integer, ByVal sChar As String) As String
        Dim sFormatString As String = ""
        sValorInicial = NVL(sValorInicial, "").Trim("")

        Try
            Select Case True
                Case Len(sValorInicial) > iTamanho
                    sFormatString = Mid$(sValorInicial, 1, iTamanho)
                Case Len(sValorInicial) < iTamanho
                    Select Case iLado
                        Case 1 'Direita
                            sFormatString = StrDup(iTamanho - Len(sValorInicial), sChar) + sValorInicial
                        Case 2 'Esquerda
                            sFormatString = sValorInicial + StrDup(iTamanho - Len(sValorInicial), sChar)
                    End Select

                Case Len(sValorInicial) = iTamanho
                    sFormatString = sValorInicial
            End Select
        Catch ex As Exception
            sFormatString = ""
        End Try

        Return sFormatString
    End Function


    Public Function UltimoDiaMes(ByVal Data As Date) As Date
        Dim dData As Date = Nothing
        For x As Int16 = 31 To 1 Step -1
            If IsDate(x & "/" & Data.Month & "/" & Data.Year) Then
                dData = CType(x & "/" & Data.Month & "/" & Data.Year, Date)
                Exit For
            End If
        Next

        Return dData
    End Function

    Public Function PrimeiroDiaMes(ByVal Data As Date) As Date
        Dim dData As Date = Nothing
        dData = CType("01/" & Data.Month & "/" & Data.Year, Date)

        Return dData
    End Function

    Public Function SetBotao(ByVal ModoForm As Int16, ByVal Toolbar As ToolBar, ByVal NomeBotao As String) As Boolean
        Dim bRet As Boolean
        If ModoForm <> 1 Then
            For x As Int16 = 0 To Toolbar.Buttons.Count - 1
                If Toolbar.Buttons(x).Text = NomeBotao Then
                    bRet = True
                    Exit For
                End If
            Next
        End If

        Return bRet
    End Function

    Public Function SetModoForm(ByVal xForm As Form, ByVal CodMenu As Int16, ByVal CodTransacao As String) As Int16
        Dim iRet As Int16
        iRet = 2

        SetControles(xForm, IIf(iRet = 2, True, False), True)

        Return iRet
    End Function

    Public Sub SetControles(ByVal xForm As Object, ByVal bValor As Boolean, Optional ByVal bFlagCampo As Boolean = False)
        Dim Control As Object

    End Sub

    Public Function MontaStringConexao(ByVal Usuario As String, ByVal Senha As String) As String
        Dim sStrConn As String = "Data Source=" & psServidor
        sStrConn += ";User ID=" & Usuario & ";Password=" & Senha
        Return sStrConn
    End Function
    Public Function MontaStringConexaoOleDB(ByVal Usuario As String, ByVal Senha As String) As String
        Dim sStrConn As String = "Provider=OraOLEDB.Oracle;Data Source=" & psServidor & ";User Id=" & Usuario & ";Password = " & Senha & ""
        Return sStrConn
    End Function

    Public Function ExtraiValorString(ByVal sStr As String, ByVal Posicao As Int32, ByVal Tamanho As Int32) As String
        If Posicao - 1 + Tamanho > sStr.Length Then
            Return sStr.Substring(Posicao - 1, sStr.Length - (Posicao - 1)).Trim
        Else
            Return sStr.Substring(Posicao - 1, Tamanho).Trim
        End If
    End Function

    Public Function ContaLinhasVisiveis(ByVal oGrid As DataGridView) As Int32
        Dim iLinha As Int32
        For x As Int32 = 0 To oGrid.Rows.Count - 1
            If oGrid.Rows(x).Visible Then iLinha += 1
        Next

        Return iLinha
    End Function

    Public Function CriaElemento(ByRef xmldoc As XmlDocument, ByVal Nome As String) As XmlElement

        Dim xmlNode As XmlElement
        Dim sPrefix As String = ""
        If Nome.ToString.IndexOf(":") > -1 Then
            sPrefix = Nome.Substring(0, Nome.IndexOf(":"))
            xmlNode = xmldoc.CreateElement(sPrefix, Nome.Replace(sPrefix & ":", ""), sPrefix)
        Else
            xmlNode = xmldoc.CreateElement(Nome, "")
        End If

        Return xmlNode

    End Function

    Public Function CriaElementoPaiComXML(ByRef xmldoc As XmlDocument, ByVal Nome As String) As XmlElement
        Dim xmlNode As XmlElement
        Dim sPrefix As String = ""
        'If Nome.ToString.IndexOf(":") > -1 Then
        sPrefix = Nome.Substring(0, Nome.IndexOf(":"))
        '    xmlNode = xmldoc.CreateElement(sPrefix, Nome.Replace(sPrefix & ":", ""), sPrefix)
        'Else
        xmlNode = xmldoc.CreateElement(Nome, "")
        'End If

        Return xmlNode
    End Function

    Public Function CriaElementoPai(ByRef xmldoc As XmlDocument, ByVal Nome As String) As XmlElement
        Dim xmlNode As XmlElement
        'Dim sPrefix As String = ""
        'If Nome.ToString.IndexOf(":") > -1 Then
        '    sPrefix = Nome.Substring(0, Nome.IndexOf(":"))
        '    xmlNode = xmldoc.CreateElement(sPrefix, Nome.Replace(sPrefix & ":", ""), sPrefix)
        'Else
        'End If

        xmlNode = xmldoc.CreateElement(Nome, "")

        Return xmlNode
    End Function

    Public Function CriaElementoComPAIeNamespace(ByRef xmldoc As XmlDocument, ByVal Nome As String, ByVal namespaceURI As String) As XmlElement
        Dim xmlNode As XmlElement
        Dim sPrefix As String = ""
        If Nome.ToString.IndexOf(":") > -1 Then
            sPrefix = Nome.Substring(0, Nome.IndexOf(":"))
            xmlNode = xmldoc.CreateElement(sPrefix, Nome.Replace(sPrefix & ":", ""), namespaceURI)
        Else
            xmlNode = xmldoc.CreateElement(Nome, namespaceURI)
        End If
        Return xmlNode
    End Function

    Public Function CriaElemento(ByRef xmldoc As XmlDocument, ByVal Nome As String, ByVal Valor As String) As XmlElement
        Dim xmlNode As XmlElement

        If Valor <> "" Then
            xmlNode = CriaElemento(xmldoc, Nome)
            xmlNode.InnerText = Valor
        End If

        Return xmlNode
    End Function

    Public Function CriaElemento(ByRef xmldoc As XmlDocument, ByRef NoPai As XmlElement, ByVal Nome As String, ByVal Valor As String)
        Dim xmlNode As XmlElement
        Dim sPrefix As String = ""

        If Valor <> "" Then
            If Nome.ToString.IndexOf(":") > -1 Then
                sPrefix = Nome.Substring(0, Nome.IndexOf(":"))
                xmlNode = xmldoc.CreateElement(sPrefix, Nome.Replace(sPrefix & ":", ""), sPrefix)
            Else
                xmlNode = xmldoc.CreateElement(Nome, Nothing)
            End If

            If Valor <> " " Then
                xmlNode.InnerText = Valor
            End If
            NoPai.AppendChild(xmlNode)
        End If
    End Function

    Public Function CriaElementoPaiComDoisXML(ByRef xmldoc As XmlDocument, ByRef NoPai As XmlElement, ByVal Nome As String, ByVal Valor As String)
        Dim xmlNode As XmlElement
        xmlNode = xmldoc.CreateElement(Nome, Nothing)

        NoPai.AppendChild(xmlNode)
    End Function

    Public Function CriaElementoComNamespace(ByRef xmldoc As XmlDocument, ByVal Nome As String, ByVal namespaceURI As String) As XmlElement
        Dim xmlNode As XmlElement
        Dim sPrefix As String = ""
        If Nome.ToString.IndexOf(":") > -1 Then
            sPrefix = Nome.Substring(0, Nome.IndexOf(":"))
            xmlNode = xmldoc.CreateElement(sPrefix, Nome.Replace(sPrefix & ":", ""), namespaceURI)
        Else
            xmlNode = xmldoc.CreateElement(Nome, namespaceURI)
        End If

        Return xmlNode
    End Function

    Public Function CriaElementoComNamespaceEValor(ByRef xmldoc As XmlDocument, ByRef NoPai As XmlElement, ByVal Nome As String, ByVal Valor As String, ByVal namespaceURI As String)
        Dim xmlNode As XmlElement
        Dim sPrefix As String = ""

        If Valor <> "" Then
            If Nome.ToString.IndexOf(":") > -1 Then
                sPrefix = Nome.Substring(0, Nome.IndexOf(":"))
                xmlNode = xmldoc.CreateElement(sPrefix, Nome.Replace(sPrefix & ":", ""), namespaceURI)
            Else
                xmlNode = xmldoc.CreateElement(Nome, namespaceURI)
            End If

            If Valor <> " " Then xmlNode.InnerText = Valor
            NoPai.AppendChild(xmlNode)
        End If
    End Function

    Public Function CriaElemento(ByRef xmldoc As XmlDocument, ByRef NoPai As XmlElement, ByVal Nome As String)
        Dim xmlNode As XmlElement
        Dim sPrefix As String = ""
        If Nome.ToString.IndexOf(":") > -1 Then
            sPrefix = Nome.Substring(0, Nome.IndexOf(":"))
            xmlNode = xmldoc.CreateElement(sPrefix, Nome.Replace(sPrefix & ":", ""), sPrefix)
        Else
            xmlNode = xmldoc.CreateElement(Nome, Nothing)
        End If

        NoPai.AppendChild(xmlNode)
    End Function

    Public Function FormataNumeroSemZero(ByVal Numero As Object, ByVal ComDecimal As Boolean) As String
        Dim retorno As String

        If ComDecimal Then
            retorno = Format(CType(NVL(Numero, 0), Double), "#############0.00").Replace(",", ".")
        Else
            retorno = Format(CType(NVL(Numero, 0), Double), "#############000").Replace(",", ".")
        End If

        Return retorno
    End Function

    Public Function FormataNumero(ByVal Numero As String, ByVal Tamanho As Int16, Optional ByVal ComDecimal As Boolean = False) As String
        If Not IsNumeric(Numero) Then
            FormataNumero = Numero & StrDup(Tamanho - Len(Numero), " ")
            Exit Function
        End If

        If Numero.Trim.Length > 0 Then
            If Not ComDecimal Then
                If CType(NVL(Numero, "0"), Double) < 0 Then
                    If Len(Replace(Replace(CType(Numero, String), ",", ""), ".", "")) < Tamanho Then
                        Return "-" & StrDup((Tamanho - 1) - Len(Replace(Replace(Replace(Numero, ",", ""), ".", ""), "-", "")), "0") & Replace(Replace(Replace(CType(Numero, String), ",", ""), ".", ""), "-", "")
                    Else
                        Return "-" & Mid(Replace(Replace(Replace(CType(Numero, String), ",", ""), ".", ""), "-", ""), 1, Tamanho - 1)
                    End If
                Else
                    If Len(Replace(Replace(CType(Numero, String), ",", ""), ".", "")) < Tamanho Then
                        Return StrDup(Tamanho - Len(Replace(Replace(CType(Numero, String), ",", ""), ".", "")), "0") & Replace(Replace(CType(Numero, String), ",", ""), ".", "")
                    Else
                        Return Mid(Replace(Replace(CType(Numero, String), ",", ""), ".", ""), 1, Tamanho)
                    End If
                End If
            Else
                If CType(NVL(Numero, "0"), Double) < 0 Then
                    If Len(CType(Numero, String)) < Tamanho Then
                        Return "-" & StrDup((Tamanho - 1) - Len(Replace(Replace(Numero, ",", "."), "-", "")), "0") & Replace(Replace(CType(Numero, String), ",", "."), "-", "")
                    Else
                        Return "-" & Mid(Replace(Replace(CType(Numero, String), ",", "."), "-", ""), 1, Tamanho - 1)
                    End If
                Else
                    If Len(Replace(CType(Numero, String), ",", ".")) < Tamanho Then
                        Return StrDup(Tamanho - Len(Replace(CType(Numero, String), ",", ".")), "0") & Replace(CType(Numero, String), ",", ".")
                    Else
                        Return Mid(Replace(CType(Numero, String), ",", "."), 1, Tamanho)
                    End If
                End If
            End If
        End If
    End Function

    Public Function FormataDuasCasasSemArredondar(ByVal d As Double, ByVal casasDecimais As Integer) As String
        casasDecimais = CType(Math.Pow(10, casasDecimais), Integer)
        Return (Math.Floor(d * casasDecimais) / casasDecimais).ToString
    End Function

    Public Function FormataZerosADireita(ByVal Numero As String) As String
        If InStr(Numero, ",") Then
            Return Numero
        Else
            Return Numero & ",00"
        End If
    End Function

    Public Function FormataString(ByVal sString As String, ByVal Tamanho As Int16) As String
        If Tamanho < Len(sString) Then
            Return sString.Substring(0, Tamanho)
        Else
            Return RTrim(LTrim(sString)) & StrDup(Tamanho - Len(RTrim(LTrim(sString))), " ")
        End If
    End Function

    Public Function FormataString(ByVal sValorInicial As String, ByVal iTamanho As Integer, ByVal iLado As Integer, ByVal sChar As String) As String
        Dim sFormatString As String = ""
        Try
            Select Case True
                Case Len(sValorInicial) > iTamanho
                    sFormatString = Mid$(sValorInicial, 1, iTamanho)
                Case Len(sValorInicial) < iTamanho
                    Select Case iLado
                        Case 1 'Esquerda
                            sFormatString = StrDup(iTamanho - Len(sValorInicial), sChar) + sValorInicial
                        Case 2 'Direita
                            sFormatString = sValorInicial + StrDup(iTamanho - Len(sValorInicial), sChar)
                    End Select

                Case Len(sValorInicial) = iTamanho
                    sFormatString = sValorInicial
            End Select
        Catch ex As Exception
            sFormatString = ""
        End Try

        Return sFormatString
    End Function

    Public Sub ProcuraGrupo(ByVal oCodGrupo As TextBox, ByVal oNomeGrupo As TextBox)
        If oCodGrupo.Text <> "" Then
            oNomeGrupo.Text = ExecuteSearch("SELECT NOM_GRUPO_CONTRATO FROM PCB_GRUPO_CONTRATO WHERE COD_GRUPO_CONTRATO=" & oCodGrupo.Text & " AND COD_UNIDADE_NEGOCIO=" & piCodUnidade)
        Else
            oNomeGrupo.Text = ""
        End If
    End Sub

    Public Function ExtraiNomeArquivo(ByVal Caminho As String) As String
        Dim sRet As String
        If Caminho.LastIndexOf("\") > -1 Then
            sRet = Mid(Caminho, Caminho.LastIndexOf("\") + 2)
        Else
            sRet = ""
        End If

        Return sRet
    End Function

    Public Function ExtraiDiretorio(ByVal Caminho As String) As String
        Dim sRet As String
        If Caminho.LastIndexOf("\") > -1 Then
            sRet = Mid(Caminho, 1, Caminho.LastIndexOf("\"))
        Else
            sRet = ""
        End If

        Return sRet
    End Function

    Public Sub ReCalculaPosicao(ByVal oGrid As DataGridView, ByVal CampoPosicaoInicial As String, ByVal CampoPosicaoFinal As String, Optional ByVal bZero As Boolean = False, Optional ByVal CampoStatus As String = "", Optional ByVal ValorCampoStatus As String = "")
        Dim iPos = IIf(bZero, 0, 1)
        Dim iDif As Int32
        Dim dc As DataGridViewRow
        For x As Int32 = 0 To oGrid.Rows.Count - 1
            dc = oGrid.Rows(x)
            If dc.Visible Then
                iDif = dc.Cells(CampoPosicaoFinal).Value - dc.Cells(CampoPosicaoInicial).Value
                dc.Cells(CampoPosicaoInicial).Value = iPos
                iPos += iDif
                dc.Cells(CampoPosicaoFinal).Value = iPos
                iPos += 1
                If CampoStatus <> "" Then
                    dc.Cells(CampoStatus).Value = IIf(ValorCampoStatus = "", "A", ValorCampoStatus)
                End If
            End If
        Next
    End Sub

    Public Sub LimpaStatusGrid(ByVal oGrid As DataGridView, ByVal CampoStatus As String, Optional ByVal Unico As Int32 = -1)
        Dim dc As DataGridViewRow
        Dim iTotal As Int32
        If Unico = -1 Then
            iTotal = oGrid.Rows.Count - 1
            Unico = 0
        Else
            iTotal = Unico
        End If
        For x As Int32 = Unico To iTotal
            dc = oGrid.Rows(x)
            dc.Cells(CampoStatus).Value = ""
        Next
    End Sub

    Public Function DataValida(ByVal oMaskedTextBox As MaskedTextBox) As Boolean
        Dim bRet As Boolean
        Try
            If RetiraMascara(oMaskedTextBox) = "" Then
                bRet = True
            Else
                bRet = IsDate(CType(oMaskedTextBox.Text, Date))
            End If
        Catch ex As Exception
            msgAviso("Data inválida!")
        End Try
        Return bRet
    End Function

    Public Function PesquisaDuplicado(ByVal oGrid As DataGridView, ByVal oColGrid() As String, ByVal oColValor() As String) As Boolean
        Dim bTodos As Boolean = False
        Dim oCols(oColGrid.GetUpperBound(0), 1) As String

        For x As Int16 = 0 To oColGrid.GetUpperBound(0)
            oCols(x, 0) = oColGrid(x)
        Next

        For Each dc As DataGridViewRow In oGrid.Rows
            If dc.Visible Then
                For x As Int16 = 0 To oColGrid.GetUpperBound(0)
                    oCols(x, 1) = Nothing
                Next

                For y As Int16 = 0 To oCols.GetUpperBound(0)
                    For x As Int16 = 0 To oGrid.Columns.Count - 1
                        If oGrid.Columns(x).Name = oCols(y, 0) Then
                            If NVL(dc.Cells(x).Value, "") = NVL(oColValor(y), "") Then
                                oCols(y, 1) = "x"
                                Exit For
                            End If
                        End If

                    Next
                Next

                bTodos = True

                For x As Int16 = 0 To oCols.GetUpperBound(0)
                    If oCols(x, 1) = "" Then
                        bTodos = False
                        Exit For
                    End If
                Next

                If bTodos = True Then Return bTodos
            End If
        Next

        Return bTodos

    End Function

    Public Sub PesquisaGenerica(ByVal TopForm As Long, ByVal LeftForm As Long, ByVal WidthForm As Long, ByVal TituloForm As String, ByVal NomeCampo As String, ByVal Formato As String, ByVal SQL As String)
        Dim frm As New frmVisualiza
        frm.Top = TopForm
        frm.Left = LeftForm
        frm.Width = WidthForm

        If NomeCampo <> "" Then frm.dgDados.Columns(0).DataPropertyName = NomeCampo
        If Formato <> "" Then frm.dgDados.Columns(0).DefaultCellStyle.Format = Formato

        Dim dt As DataTable = ExecuteRecordset(SQL)
        CarregaGrid(frm.dgDados, dt)
        frm.dgDados.Width = frm.Width - 20
        frm.dgDados.Columns(0).Width = frm.dgDados.Width - 20
        frm.Text = TituloForm
        frm.ShowDialog()
    End Sub

    Public Sub PesquisaGenerica(ByVal TopForm As Long, ByVal LeftForm As Long, ByVal WidthForm As Long, ByVal TituloForm As String, ByVal NomeCampo As String, ByVal Formato As String, ByVal dt As DataTable)
        Dim frm As New frmVisualiza
        frm.Top = TopForm
        frm.Left = LeftForm
        frm.Width = WidthForm

        If NomeCampo <> "" Then frm.dgDados.Columns(0).DataPropertyName = NomeCampo
        If Formato <> "" Then frm.dgDados.Columns(0).DefaultCellStyle.Format = Formato

        CarregaGrid(frm.dgDados, dt)
        frm.dgDados.Width = frm.Width - 20
        frm.dgDados.Columns(0).Width = frm.dgDados.Width - 20
        frm.Text = TituloForm
        frm.ShowDialog()
    End Sub

    Public Function VerificaColunaSelecionada(ByVal oGrid As DataGridView, ByVal iLinha As Integer) As Boolean
        For x As Integer = 0 To oGrid.ColumnCount - 1
            If oGrid.Rows(iLinha).Cells.Item(x).Selected Then Return True
        Next

        Return False
    End Function

    Public Function UltimaPosicao(ByVal dg As DataGridView, ByVal sCampo As String) As String
        Dim lUltimaPosicao As Long = 0
        Dim x As Int64
        For x = dg.Rows.Count - 1 To 0 Step -1
            If dg.Rows(x).Visible Then
                lUltimaPosicao = dg.Rows(x).Cells(sCampo).Value
                Exit For
            End If
        Next
        lUltimaPosicao = lUltimaPosicao + 1
        Return lUltimaPosicao
    End Function

    Public Function VerificaColunaSelecionada(ByVal oGrid As DataGridView, ByVal iLinha As Int16, ByRef iLinhaSelecionada As Long) As Boolean
        For x As Int16 = 0 To oGrid.ColumnCount - 1
            If oGrid.Rows(iLinha).Cells.Item(x).Selected Then
                iLinhaSelecionada = x
                Return True
            End If
        Next

        Return False
    End Function

    Public Function RetiraMascara(ByVal oMaskedTextBox As MaskedTextBox) As String
        Dim mValor As MaskFormat
        Dim sValor As String
        mValor = oMaskedTextBox.TextMaskFormat
        oMaskedTextBox.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals
        sValor = oMaskedTextBox.Text
        oMaskedTextBox.TextMaskFormat = mValor

        Return sValor
    End Function

    Public Function RetiraMascara(ByVal sValor As String) As String
        If sValor = "" Then Return sValor
        Return sValor.Replace("/", "").Replace("-", "").Replace(".", "").Replace(" ", "").Replace("_", "")
    End Function

    Public Sub AdicionaArray(ByRef aArray() As String, ByVal sString As String)
        If sString.Substring(sString.Length - 1, 1) = ";" Then
            sString = sString.Substring(0, sString.Length - 1)
        End If
        Dim aTemp() As String = sString.Split(";")
        If IsNothing(aArray) Then ReDim aArray(0)
        For x As Int16 = 0 To aTemp.GetUpperBound(0)
            ReDim Preserve aArray(aArray.GetUpperBound(0) + 1)
            aArray(aArray.GetUpperBound(0) - 1) = aTemp(x)
        Next
        ReDim Preserve aArray(aArray.GetUpperBound(0) - 1)
    End Sub

    Public Function ProcuraValor(ByVal Valor As String, ByVal Controle As ComboBox, Optional ByVal iCol As Int16 = 0) As Int16
        Dim iRet As Int16 = -1
        Valor = NVL(Valor, "")
        For x As Int16 = 0 To Controle.Items.Count - 1
            Dim item As DataRowView = Controle.Items.Item(x)
            If iCol = 0 Then
                If item(0).ToString = Valor Then iRet = x
            Else
                If item(iCol).ToString = Valor Then iRet = x
            End If
        Next

        Return iRet
    End Function

    Public Sub CarregaGrid(ByVal oGrid As DataGridView, ByVal dt As DataTable, Optional ByVal CampoDestaque As String = "", Optional ByVal ValorDestaque As String = "", Optional ByVal LimpaGrid As Boolean = True, Optional ByVal Ordena As Boolean = False, Optional ByVal ColunaOrdem As Int16 = 0, Optional ByVal DirecaoOrdem As String = "asc")

        Dim lLinha As Long
        Dim sCampo As String = ""
        Dim bBranco As Boolean = True

        If LimpaGrid Then
            oGrid.DataSource = Nothing
            oGrid.Rows.Clear()
        End If

        oGrid.DefaultCellStyle.ForeColor = Color.Blue
        oGrid.RowHeadersWidth = 25

        For Each oRow As DataRow In dt.Rows
            oGrid.Rows.Add()
            Dim row As DataGridViewRow = oGrid.Rows(lLinha)
            bBranco = True
            For x As Int16 = 0 To oGrid.ColumnCount - 1
                If oGrid.Columns(x).DataPropertyName.ToString <> "" Then
                    'Se tiver o caracter '_' no final extrai
                    If oGrid.Columns(x).DataPropertyName.ToString.Substring(oGrid.Columns(x).DataPropertyName.ToString.Length - 1, 1) = "_" Then
                        sCampo = oGrid.Columns(x).DataPropertyName.ToString.Substring(1, oGrid.Columns(x).DataPropertyName.ToString.Length - 1).ToString
                    Else
                        sCampo = oGrid.Columns(x).DataPropertyName.ToString
                    End If
                    If TypeOf oRow.Item(sCampo.ToString) Is DateTime Then
                        oGrid.Rows(oGrid.Rows.Count - 1).Cells(x).Value = Format(oRow.Item(sCampo.ToString), "dd/MM/yyyy").ToString
                    Else
                        If TypeOf oRow.Item(sCampo.ToString) Is Decimal Then
                            oGrid.Rows(oGrid.Rows.Count - 1).Cells(x).Value = oRow.Item(sCampo)
                        Else
                            oGrid.Rows(oGrid.Rows.Count - 1).Cells(x).Value = oRow.Item(sCampo)
                        End If
                    End If
                Else
                    If oGrid.Rows(oGrid.Rows.Count - 1).Cells(x).ValueType.FullName = "System.Boolean" Then
                        oGrid.Rows(oGrid.Rows.Count - 1).Cells(x).Value = False
                    Else
                        oGrid.Rows(oGrid.Rows.Count - 1).Cells(x).Value = ""
                    End If

                End If
                If NVL(oGrid.Rows(oGrid.Rows.Count - 1).Cells(x).Value, "") <> "" Then
                    bBranco = False
                End If
                'Para mudar a cor da linha do grid dependendo do parametro passado ou do registro cancelado
                If row.DefaultCellStyle.ForeColor <> Color.Red Then
                    If NVL(row.Cells(oGrid.Columns(x).Name).Value, "") = "CANCELADO" Then
                        row.DefaultCellStyle.ForeColor = Color.Red
                        row.DefaultCellStyle.SelectionForeColor = Color.Red
                        row.DefaultCellStyle.SelectionBackColor = Color.LightBlue
                    Else
                        If CampoDestaque <> "" And oGrid.Columns(x).Name = CampoDestaque Then
                            If (ValorDestaque = "NULL" And IsDBNull(row.Cells(CampoDestaque).Value)) Or _
                               (ValorDestaque = "NOT NULL" And NVL(row.Cells(CampoDestaque).Value, "") <> "") Then
                                row.DefaultCellStyle.ForeColor = Color.Red
                                row.DefaultCellStyle.SelectionForeColor = Color.Red
                                row.DefaultCellStyle.SelectionBackColor = Color.LightBlue
                            Else
                                If row.Cells(CampoDestaque).Value.ToString = ValorDestaque Then
                                    row.DefaultCellStyle.ForeColor = Color.Red
                                    row.DefaultCellStyle.SelectionForeColor = Color.Red
                                    row.DefaultCellStyle.SelectionBackColor = Color.LightBlue
                                End If
                            End If
                        End If
                    End If
                End If
            Next
            If bBranco Then
                oGrid.Rows.Remove(row)
            Else
                lLinha += 1
            End If
        Next

        AddHandler oGrid.MouseLeave, AddressOf CommitEdit
        AddHandler oGrid.DataError, AddressOf MsgGrid ' Mensagem

        'Ordena pela coluna passada para atualizar a barra de scroll 
        'evitando assim um bug na atualização da barra
        If Ordena Then
            Dim dc As DataGridViewColumn = oGrid.Columns(ColunaOrdem)
            If DirecaoOrdem = "asc" Then
                oGrid.Sort(dc, System.ComponentModel.ListSortDirection.Ascending)
            ElseIf DirecaoOrdem = "desc" Then
                oGrid.Sort(dc, System.ComponentModel.ListSortDirection.Descending)
            End If
        End If

        oGrid.PerformLayout()
    End Sub

    Private Sub MsgGrid(ByVal sender As Object, ByVal e As DataGridViewDataErrorEventArgs)

    End Sub

    Public Function NVL(ByVal Valor As Object, ByVal Result As Object) As String
        If IsNothing(Valor) Or IsDBNull(Valor) Then
            Return Result
        Else
            If CType(Valor, String) = "" Then
                Return Result
            Else
                If CType(Valor, String) = "NULL" Then
                    Return Result
                Else
                    Return Valor.ToString.Trim
                End If
            End If
        End If
    End Function

    Private Sub CommitEdit(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            sender.CommitEdit(DataGridViewDataErrorContexts.Commit)
        Catch ex As Exception

        End Try
    End Sub

    Public Function ExecuteSQL(ByVal sSQL As String) As Boolean
        Dim lCmd As New OracleCommand
        Dim bRetorno As Boolean

        If Not IsNothing(oTrans) Then lCmd.Transaction = oTrans

        Try
            If oConn.State = ConnectionState.Closed Then
                Throw New Exception("Erro ao abrir banco de dados, faça novo login no sistema")
                Dim frm As New frmLogin
                frm.ShowDialog()
            End If
            lCmd.Connection = oConn
            lCmd.CommandText = sSQL
            lCmd.CommandType = CommandType.Text
            lCmd.ExecuteNonQuery()
            bRetorno = True
        Catch ex As Exception
            Dim oArquivo As System.IO.File
            Dim oEscrever As System.IO.StreamWriter
            '
            oEscrever = New IO.StreamWriter("c:\CADFUN\log.txt")
            oEscrever.Write(sSQL)
            oEscrever.Close()

            bRetorno = False
        Finally
        End Try

        Return bRetorno
    End Function

    Public Function ExecuteSql(ByVal sSQL As String, ByVal aParam As OracleParameterCollection) As OracleParameterCollection
        Dim lCmd As New OracleCommand

        If Not IsNothing(oTrans) Then lCmd.Transaction = oTrans

        Try
            If oConn.State = ConnectionState.Closed Then
                Throw New Exception("Erro ao abrir banco de dados, faça novo login no sistema")
            End If
            lCmd.Connection = oConn
            lCmd.CommandText = sSQL
            lCmd.CommandType = CommandType.Text
            Dim cmd As OracleParameter
            For x As Int16 = 0 To aParam.Count - 1
                cmd = New OracleParameter(aParam(x).ParameterName, aParam(x).OracleType, aParam(x).Size)
                cmd.Direction = aParam(x).Direction
                cmd.Value = aParam(x).Value
                lCmd.Parameters.Add(cmd)
            Next
            lCmd.ExecuteNonQuery()
        Catch ex As OracleClient.OracleException
            msgErro(ex.Message, ex)
            Throw ex
        End Try

        Return lCmd.Parameters
    End Function

    Public Function ExecuteSQLComAuditoria(ByVal sSQL As String, ByVal sSqlAuditoria As String, ByVal classe As String, ByVal metoto As String, ByVal tipoOperacao As String, ByVal tabela As String) As Boolean
        Dim lCmd As New OracleCommand
        Dim bRetorno As Boolean
        Dim logJson As String = String.Empty
        Dim dtAudit As DataTable


        Return bRetorno
    End Function



    Public Function DataTableToJSONWithStringBuilder(ByVal table As DataTable, ByVal i As Integer) As String
        Dim JSONString = New StringBuilder()
        If table.Rows.Count > 0 Then
            JSONString.Append("[")

            JSONString.Append("{")
            For j As Integer = 0 To table.Columns.Count - 1
                If j < table.Columns.Count - 1 Then
                    JSONString.Append("""" + table.Columns(j).ColumnName.ToString() + """:" + """" + table.Rows(i)(j).ToString() + """,")
                ElseIf j = table.Columns.Count - 1 Then
                    JSONString.Append("""" + table.Columns(j).ColumnName.ToString() + """:" + """" + table.Rows(i)(j).ToString() + """")
                End If
            Next

            JSONString.Append("}")

        End If

        JSONString.Append("]")

        Return JSONString.ToString()
    End Function

    Public Function AdicionaLinhaBranco(ByVal dt As DataTable) As DataTable
        Dim oRow As DataRow
        Dim dtC As DataTable = dt.Clone
        Dim bBranco As Boolean = True

        For w As Int32 = 0 To dt.Rows.Count - 1
            oRow = dtC.NewRow
            For x As Int16 = 0 To dt.Columns.Count - 1
                If bBranco Then
                    oRow(dt.Columns(x).ColumnName) = SetaValorTipoColuna(dt.Columns(x).DataType)
                Else
                    oRow(dt.Columns(x).ColumnName) = dt.Rows(w).Item(x)
                End If
            Next
            dtC.Rows.Add(oRow)
            If bBranco Then
                w = -1
                bBranco = False
            End If
        Next

        Return dtC
    End Function

    Private Function SetaValorTipoColuna(ByVal Tipo As System.Type) As Object
        Dim oRet As Object = ""

        If Tipo.FullName = "System.Decimal" Or Tipo.FullName = "System.Double" Or Tipo.FullName = "System.Int32" Or Tipo.FullName = "System.Int16" Then
            oRet = 0
        ElseIf Tipo.FullName = "System.DateTime" Then
            oRet = ""
        ElseIf Tipo.FullName = "System.String" Then
            oRet = ""
        End If

        Return oRet
    End Function

    Public Sub FormataGridAlterado(ByVal oGrid As DataGridView)
        Dim dc As DataGridViewRow
        For x As Int32 = 0 To oGrid.Rows.Count - 1
            For y As Int16 = 0 To oGrid.ColumnCount - 1
                If oGrid.Columns(y).Name.ToString.ToUpper.Substring(0, 6) = "STATUS" Then
                    dc = oGrid.Rows(x)
                    If dc.Cells(y).Value = "A" Or dc.Cells(y).Value = "I" Then
                        dc.DefaultCellStyle.BackColor = Color.LightGray
                    ElseIf dc.Cells(y).Value = "E" Then
                        dc.DefaultCellStyle.ForeColor = Color.Red
                        dc.DefaultCellStyle.BackColor = Color.White
                        dc.DefaultCellStyle.SelectionForeColor = Color.Red
                        dc.DefaultCellStyle.SelectionBackColor = Color.LightBlue
                    End If
                End If
            Next
        Next
    End Sub

    Public Function ExecuteProc(ByVal sSQL As String, ByVal aParam As OracleParameterCollection) As OracleParameterCollection
        Dim lCmd As New OracleCommand

        If Not IsNothing(oTrans) Then lCmd.Transaction = oTrans

        Try
            If oConn.State = ConnectionState.Closed Then
                Throw New Exception("Erro ao abrir banco de dados, faça novo login no sistema")
            End If
            lCmd.Connection = oConn
            lCmd.CommandText = sSQL
            lCmd.CommandType = CommandType.StoredProcedure
            Dim cmd As OracleParameter
            For x As Int16 = 0 To aParam.Count - 1
                cmd = New OracleParameter(aParam(x).ParameterName, aParam(x).OracleType, aParam(x).Size)
                cmd.Direction = aParam(x).Direction
                cmd.Value = aParam(x).Value
                lCmd.Parameters.Add(cmd)
            Next
            lCmd.ExecuteNonQuery()
        Catch ex As OracleClient.OracleException
            msgErro(ex.Message, ex)
            Throw ex 'Chamado 252517 - 30/12/2013 - Flavio Silva
        End Try

        Return lCmd.Parameters
    End Function

    Public Function ExecuteProcComAuditoria(ByVal sSQL As String, ByVal aParam As OracleParameterCollection, ByVal sSqlAuditoria As String, ByVal classe As String, ByVal metoto As String, ByVal tipoOperacao As String, ByVal tabela As String) As OracleParameterCollection
        Dim lCmd As New OracleCommand
        Dim logJson As String = String.Empty
        Dim dtAudit As DataTable


        Return lCmd.Parameters
    End Function

    Public Function ExecuteProcSemParam(ByVal sSQL As String) As Boolean
        Dim lCmd As New OracleCommand
        Dim bRet As Boolean

        If Not IsNothing(oTrans) Then lCmd.Transaction = oTrans

        Try
            If oConn.State = ConnectionState.Closed Then
                Throw New Exception("Erro ao abrir banco de dados, faça novo login no sistema")
                Return bRet
            End If
            lCmd.Connection = oConn
            lCmd.CommandText = sSQL
            lCmd.CommandType = CommandType.StoredProcedure
            lCmd.ExecuteNonQuery()
        Catch ex As OracleClient.OracleException
            msgErro(ex.Message, ex)
            Return bRet
        End Try

        Return bRet = True
    End Function

    Public Function ExecuteSearch(ByVal sSQL As String) As String
        Dim dt As New DataTable
        Dim sRet As String = ""

        Try
            If oConn.State = ConnectionState.Closed Then
                Throw New Exception("Erro ao abrir banco de dados, faça novo login no sistema")
            End If
            dt = ExecuteRecordset(sSQL)
            If dt.Rows.Count > 0 Then sRet = IIf(IsDBNull(dt.Rows(0).Item(0)), "1", dt.Rows(0).Item(0))
        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try

        Return sRet
    End Function

    Public Function OpenConnect(ByVal Usuario As String, ByVal Senha As String, Optional ByVal MostraMsg As Boolean = True) As Boolean
        Dim bRet As Boolean
        Try
            If Not IsNothing(oConn) Then
                If oConn.State = ConnectionState.Open Then oConn.Close()
            End If

            oConn = New OracleConnection(MontaStringConexao(Usuario, Senha))
            oConn.Open()
            bRet = True
        Catch ex As OracleClient.OracleException
            If MostraMsg Then
                Select Case ex.Code
                    Case 1017 : msgAlerta("Usuário ou senha inválida!")
                    Case 28000
                        msgAviso("Usuário bloqueado.")
                    Case Else : msgErro("Não foi possível conectar ao servidor," & vbCr & "Erro : " & ex.Message)
                End Select
            End If

            bRet = False
        End Try

        Return bRet
    End Function

    Public Sub CloseConnect()
        Try
            oConn.Close()
        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try
    End Sub

    Public Function ExecuteRecordsetReport(ByVal sSQL As String) As DataTable
        Dim da As New OleDbDataAdapter
        Dim ds As New DataSet
        Dim dt As New DataTable
        Try
            Dim oCn As New OleDbConnection("Provider=ORAOLEDB.Oracle;" & MontaStringConexao(psLogin, psSenha))
            da.SelectCommand = New OleDbCommand(sSQL, oCn)
            da.Fill(ds, "DataSet1")
            dt = ds.Tables(0)
        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try
        Return dt
    End Function

    Public Function ExecuteReader(ByVal sSQL As String) As DataTable
        Dim da As New OracleDataAdapter
        Dim cmd As OracleCommand
        Dim dt As New DataTable

        Try
            If oConn.State = ConnectionState.Closed Then
                Throw New Exception("Erro ao abrir banco de dados, faça novo login no sistema")
            End If

            cmd = New OracleCommand(sSQL, oConn)
            da = New OracleDataAdapter(cmd)
            da.Fill(dt)

            If Not IsNothing(oTrans) Then cmd.Transaction = oTrans
        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try

        Return dt
    End Function

    Public Function ExecuteRecordset(ByVal sSQL As String) As DataTable
        Dim da As New OracleDataAdapter
        Dim ds As New DataSet
        Dim dt As New DataTable
        Dim cmd As OracleCommand

        Try
            If oConn.State = ConnectionState.Closed Then
                Throw New Exception("Erro ao abrir banco de dados, faça novo login no sistema")
            End If

            cmd = New OracleCommand(sSQL, oConn)

            If Not IsNothing(oTrans) Then cmd.Transaction = oTrans

            da.SelectCommand = cmd
            da.Fill(ds)
            dt = ds.Tables(0)
        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try

        Return dt
    End Function

    Public Function FormataCompetencia(ByVal Data As Date) As String
        Return StrDup(2 - Len(Data.Month.ToString), "0") & Data.Month & "/" & Data.Year
    End Function

    Public Function ExecuteRecordset(ByVal sSQL As String, ByVal CommandType As CommandType, Optional ByVal Parameters As OracleParameterCollection = Nothing) As DataTable
        Dim da As New OracleDataAdapter
        Dim ds As New DataSet
        Dim dt As New DataTable
        Dim cmd As OracleCommand

        Try
            cmd = New OracleCommand(sSQL, oConn)
            cmd.CommandType = CommandType

            If Not IsNothing(Parameters) Then
                For Each Param As OracleParameter In Parameters
                    cmd.Parameters.Add(Param)
                Next
            End If

            If Not IsNothing(oTrans) Then cmd.Transaction = oTrans

            da.SelectCommand = cmd
            da.Fill(ds)
            dt = ds.Tables(0)
        Catch ex As Exception
            msgErro(ex.Message, ex)
        End Try

        Return dt
    End Function

    Public Function RetornaRecordset(ByVal sSQL As String, ByVal CommandType As CommandType, ByVal Parameters As OracleParameterCollection) As DataTable
        Dim da As New OracleDataAdapter
        Dim ds As New DataSet
        Dim dt As New DataTable
        Dim cmd As OracleCommand

        Try
            cmd = New OracleCommand(sSQL, oConn)
            cmd.CommandType = CommandType

            If Not IsNothing(Parameters) Then
                For x As Int16 = 0 To Parameters.Count - 1
                    Dim param As OracleParameter
                    param = New OracleParameter(Parameters(x).ParameterName, Parameters(x).OracleType, Parameters(x).Size)
                    param.Direction = Parameters(x).Direction
                    param.Value = Parameters(x).Value
                    cmd.Parameters.Add(param)
                Next
            End If

            If Not IsNothing(oTrans) Then cmd.Transaction = oTrans

            da.SelectCommand = cmd
            da.Fill(ds)
            dt = ds.Tables(0)
        Catch ex As Exception
            msgErro(ex.Message, ex)
            'Throw ex
        End Try

        Return dt
    End Function

    Public Sub ExportarDataTableParaCSV(ByVal dt As DataTable)
        Dim rp As ReportDocument

    End Sub

    Public Function SomentePeriodo(ByVal sender As Object) As Boolean
        Dim bValido As Boolean = True

        Try
            If sender.Text <> "" Then
                If Len(sender.Text) < 7 Then
                    bValido = False
                Else
                    If Mid(sender.text, 3, 1) <> "/" Then
                        bValido = False
                    Else
                        If CLng(Left(sender.text, 2)) < 1 Then
                            bValido = False
                        Else
                            If CLng(Left(sender.text, 2)) > 12 Then bValido = False
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            bValido = False
        End Try
        Return bValido
    End Function

    Public Function SomenteNumeros(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs, ByVal bDecimal As Boolean, Optional ByVal iNumCasas As Int16 = 0, Optional ByVal bSinal As Boolean = False) As Boolean
        Dim bRetorno As Boolean = False

        If Not Char.IsDigit(e.KeyChar) Then
            If Not Char.IsControl(e.KeyChar) Then
                If Char.IsPunctuation(e.KeyChar) Then
                    If Not bDecimal Then
                        bRetorno = True
                    Else
                        If e.KeyChar = "." Then
                            bRetorno = True
                        ElseIf InStr(1, sender.text, ",") > 0 Then
                            bRetorno = True
                        ElseIf e.KeyChar = "+" Then
                            If Not bSinal Then
                                bRetorno = True
                            Else
                                bRetorno = False
                            End If
                        End If
                    End If
                Else
                    bRetorno = True
                End If
            End If
        Else
            If sender.SelectionLength = 0 Then
                If bDecimal Then
                    If InStr(1, sender.TEXT, ",") > 0 Then
                        If Len(sender.text) > InStr(1, sender.TEXT, ",") Then
                            If Len(Mid(sender.text, InStr(1, sender.TEXT, ",") + 1)) + 1 > iNumCasas Then bRetorno = True
                        End If
                    End If
                End If
            End If
        End If

        Return bRetorno
    End Function

    Public Sub FecharForms()
        For Each xForm As Form In frmMDI.MdiChildren
            xForm.Close()
        Next
        frmMDI.MenuStrip.Items.Clear()
    End Sub

    Public Function GetLengthCPF(ByVal cpf As String) As String
        Dim lengthCpf As Integer
        lengthCpf = cpf.Length

        If lengthCpf < 11 Then
            For var As Integer = 1 To (11 - lengthCpf)
                cpf = cpf.Insert(0, "0")
            Next var
        End If
        GetLengthCPF = cpf
    End Function

    Public Function ValidaCPF(ByVal strCPFCliente As String) As Boolean
        Dim strCPFOriginal As String = strCPFCliente.Replace(".", "").Replace("-", "").Trim
        strCPFOriginal = strCPFOriginal.PadLeft(11, "0"c)
        Dim strCPF As String = Mid(strCPFOriginal, 1, 9)
        Dim strCPFTemp As String
        Dim intSoma As Integer
        Dim intResto As Integer
        Dim strDigito As String
        Dim intMultiplicador As Integer = 10
        Const constIntMultiplicador As Integer = 11
        Dim i As Integer
        '--------------------------

        If strCPFOriginal = "" Then Return True

        For i = 0 To strCPF.ToString.Length - 1
            intSoma += CInt(strCPF.ToString.Chars(i).ToString) * intMultiplicador
            intMultiplicador -= 1
        Next

        If (intSoma Mod constIntMultiplicador) < 2 Then
            intResto = 0
        Else
            intResto = constIntMultiplicador - (intSoma Mod constIntMultiplicador)
        End If

        strDigito = intResto
        intSoma = 0

        strCPFTemp = strCPF & strDigito
        intMultiplicador = 11

        For i = 0 To strCPFTemp.Length - 1
            intSoma += CInt(strCPFTemp.Chars(i).ToString) * intMultiplicador
            intMultiplicador -= 1
        Next

        If (intSoma Mod constIntMultiplicador) < 2 Then
            intResto = 0
        Else
            intResto = constIntMultiplicador - (intSoma Mod constIntMultiplicador)
        End If

        strDigito &= intResto

        If strDigito = Mid(strCPFOriginal, 10, strCPFOriginal.Length) Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Sub LimpaCampos(ByVal xForm As Object)
        Try
            Dim Control As Object
            For Each Control In xForm.Controls
                If Control.Tag <> "*" Then
                    If TypeOf Control Is TextBox Or TypeOf Control Is MaskedTextBox Then
                        Control.text = ""
                    ElseIf TypeOf Control Is RadioButton Or TypeOf Control Is CheckBox Then
                        Control.Checked = False
                    ElseIf TypeOf Control Is DataGridView Then
                        Control.Rows.clear()
                    ElseIf TypeOf Control Is ComboBox Or TypeOf Control Is ListBox Then
                        Control.SelectedIndex = -1
                    ElseIf TypeOf Control Is TabControl Or TypeOf Control Is TabPage Or TypeOf Control Is GroupBox Or TypeOf Control Is Panel Then
                        LimpaCampos(Control)
                    End If
                End If
            Next
        Catch ex As Exception
        End Try
    End Sub

    Public Sub msgAlerta(ByVal sMsg As String)

        MessageBox.Show(sMsg, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning)

    End Sub

    Public Sub msgAviso(ByVal sMsg As String)

        MessageBox.Show(sMsg, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Public Sub msgErro(ByVal sMsg As String)

        MessageBox.Show(sMsg, "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error)

    End Sub

    Public Sub msgErro(ByVal sMsg As String, ByVal Err As Exception)

        MessageBox.Show(sMsg & vbNewLine & vbNewLine & Err.Message & vbNewLine & vbNewLine & Err.StackTrace, "Ocorreu um erro", MessageBoxButtons.OK, MessageBoxIcon.Error)

    End Sub

    Public Function msgConfirma(ByVal sMsg As String) As Boolean
        Return (MessageBox.Show(sMsg, "Confirma", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.Yes)
    End Function

    Public Function ValidaNumero(ByVal Key As String) As Boolean
        If (Key >= 48 And Key <= 57) Or Key = 8 Then
            ValidaNumero = False
        Else
            ValidaNumero = True
        End If
    End Function

    Function VerificaSeEhNumero(ByVal strNumero As String) As Boolean
        Dim pattern As String = "[^0-9]"

        ' Verifica se o número corresponde a pattern/mascara
        Dim emailMatch As System.Text.RegularExpressions.Match = System.Text.RegularExpressions.Regex.Match(strNumero, pattern)

        ' Caso corresponda
        If emailMatch.Success Then
            Return False
        Else
            Return True
        End If
    End Function

    Function ValidaEmail(ByVal email As String) As Boolean
        ' Pattern ou mascara de verificação
        Dim pattern As String = "^[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"

        ' Verifica se o email corresponde a pattern/mascara
        Dim emailMatch As System.Text.RegularExpressions.Match = System.Text.RegularExpressions.Regex.Match(email, pattern)

        ' Caso corresponda
        If emailMatch.Success Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function SomenteCaracteres(ByVal key As String) As Boolean
        If (key >= 65 And key <= 90) Or (key >= 97 And key <= 122) Or key = 8 Then
            SomenteCaracteres = False
        Else
            SomenteCaracteres = True
            msgAviso("informe somente caracteres alfanuméricos")
        End If
    End Function

    Public Function ValidaCNPJ(ByVal mStrCNPJ As String) As Boolean

        Dim VAR1, VAR2, VAR3, VAR4, VAR5 As Integer
        mStrCNPJ = mStrCNPJ.Replace("/", "").Replace(".", "").Replace("-", "")

        If Len(mStrCNPJ) = 8 And Val(mStrCNPJ) > 0 Then
            VAR1 = 0
            VAR2 = 0
            VAR4 = 0
            For VAR3 = 1 To 7
                VAR1 = Val(Mid(mStrCNPJ, VAR3, 1))
                If (VAR1 Mod 2) <> 0 Then
                    VAR1 = VAR1 * 2
                End If
                If VAR1 > 9 Then
                    VAR2 = VAR2 + Int(VAR1 / 10) + (VAR1 Mod 10)
                Else
                    VAR2 = VAR2 + VAR1
                End If
            Next VAR3
            VAR4 = IIf((VAR2 Mod 10) <> 0, 10 - (VAR2 Mod 10), 0)
            If VAR4 = Val(Mid(mStrCNPJ, 8, 1)) Then
                Return True
            Else
                Return False
            End If
        Else
            If Len(mStrCNPJ) > 0 Then
                VAR1 = 0
                VAR3 = 0
                VAR4 = 0
                VAR5 = 0
                VAR2 = 5
                For VAR3 = 1 To 12
                    VAR1 = VAR1 + (Val(Mid(mStrCNPJ, VAR3, 1)) * VAR2)
                    VAR2 = IIf(VAR2 > 2, VAR2 - 1, 9)
                Next VAR3
                VAR1 = VAR1 Mod 11
                VAR4 = IIf(VAR1 > 1, 11 - VAR1, 0)
                VAR1 = 0
                VAR3 = 0
                VAR2 = 6
                For VAR3 = 1 To 13
                    VAR1 = VAR1 + (Val(Mid(mStrCNPJ, VAR3, 1)) * VAR2)
                    VAR2 = IIf(VAR2 > 2, VAR2 - 1, 9)
                Next VAR3
                VAR1 = VAR1 Mod 11
                VAR5 = IIf(VAR1 > 1, 11 - VAR1, 0)
                If (VAR4 = Val(Mid(mStrCNPJ, 13, 1)) And VAR5 = Val(Mid(mStrCNPJ, 14, 1))) Then
                    Return True
                Else
                    Return False
                End If
            Else
                Return False
            End If
        End If
    End Function

    Public Sub RemoverCaracteres(ByVal oTexto As TextBox)
        If oTexto.Text = "" Then Exit Sub
        oTexto.Text = UCase(oTexto.Text)
        oTexto.Text = Replace(oTexto.Text, "Á", "A")
        oTexto.Text = Replace(oTexto.Text, "É", "E")
        oTexto.Text = Replace(oTexto.Text, "Í", "I")
        oTexto.Text = Replace(oTexto.Text, "Ó", "O")
        oTexto.Text = Replace(oTexto.Text, "Ú", "U")
        oTexto.Text = Replace(oTexto.Text, "Ã", "A")
        oTexto.Text = Replace(oTexto.Text, "À", "A")
        oTexto.Text = Replace(oTexto.Text, "Â", "A")
        oTexto.Text = Replace(oTexto.Text, "Õ", "O")
        oTexto.Text = Replace(oTexto.Text, "Ç", "C")
        oTexto.Text = Replace(oTexto.Text, "Ü", "U")
        oTexto.Text = Replace(oTexto.Text, "Ê", "E")
        oTexto.Text = Replace(oTexto.Text, "?", " ")
        oTexto.Text = Replace(oTexto.Text, "¿", " ")
        oTexto.Text = Replace(oTexto.Text, "º", " ")
        oTexto.Text = Replace(oTexto.Text, "ª", " ")
        oTexto.Text = Replace(oTexto.Text, "", " ")
        oTexto.Text = Replace(oTexto.Text, "[", " ")
        oTexto.Text = Replace(oTexto.Text, "]", " ")

        Dim sTmp As String = ""
        For x As Int16 = 0 To oTexto.Text.Length - 1
            Select Case Asc(oTexto.Text.Substring(x, 1))
                Case 47 To 57, 65 To 90, 97 To 122, 32, 13, 14, 17, 167, 168
                Case Else
                    oTexto.Text.Replace(oTexto.Text.Substring(x, 1), "")
            End Select
        Next
    End Sub

    Public Sub RemoverCaracteres(ByVal oTexto As MaskedTextBox)

        If oTexto.Text = "" Then Exit Sub
        oTexto.Text = UCase(oTexto.Text)
        oTexto.Text = Replace(oTexto.Text, "Á", "A")
        oTexto.Text = Replace(oTexto.Text, "É", "E")
        oTexto.Text = Replace(oTexto.Text, "Í", "I")
        oTexto.Text = Replace(oTexto.Text, "Ó", "O")
        oTexto.Text = Replace(oTexto.Text, "Ú", "U")
        oTexto.Text = Replace(oTexto.Text, "Ã", "A")
        oTexto.Text = Replace(oTexto.Text, "À", "A")
        oTexto.Text = Replace(oTexto.Text, "Â", "A")
        oTexto.Text = Replace(oTexto.Text, "Õ", "O")
        oTexto.Text = Replace(oTexto.Text, "Ç", "C")
        oTexto.Text = Replace(oTexto.Text, "Ü", "U")
        oTexto.Text = Replace(oTexto.Text, "Ê", "E")
        oTexto.Text = Replace(oTexto.Text, "?", " ")
        oTexto.Text = Replace(oTexto.Text, "¿", " ")
        oTexto.Text = Replace(oTexto.Text, "º", " ")
        oTexto.Text = Replace(oTexto.Text, "ª", " ")
        oTexto.Text = Replace(oTexto.Text, "", " ")
        oTexto.Text = Replace(oTexto.Text, "[", " ")
        oTexto.Text = Replace(oTexto.Text, "]", " ")

        Dim sTmp As String = ""
        For x As Int16 = 0 To oTexto.Text.Length - 1
            Select Case Asc(oTexto.Text.Substring(x, 1))
                Case 47 To 57, 65 To 90, 97 To 122, 32, 13, 14, 17, 167, 168
                Case Else
                    oTexto.Text.Replace(oTexto.Text.Substring(x, 1), "")
            End Select
        Next
    End Sub
    Function RemoveAcentos2(ByVal texto As String) As String

        Dim vPos As Byte
        Dim i As Integer

        Const vComAcento = "ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜàáâãäåçèéêëìíîïòóôõöùúûü'´`^~()*&"
        Const vSemAcento = "AAAAAACEEEEIIIIOOOOOUUUUaaaaaaceeeeiiiiooooouuuu         "

        For i = 1 To Len(texto)
            vPos = InStr(1, vComAcento, Mid(texto, i, 1))
            If vPos > 0 Then
                Mid(texto, i, 1) = Mid(vSemAcento, vPos, 1)
            End If
        Next
        RemoveAcentos2 = texto
    End Function

    Function RemoveAcentos(ByVal texto As String) As String

        Dim vPos As Byte
        Dim i As Integer

        Const vComAcento = "ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜàáâãäåçèéêëìíîïòóôõöùúûü\/'´`^~()*&"
        Const vSemAcento = "AAAAAACEEEEIIIIOOOOOUUUUaaaaaaceeeeiiiiooooouuuu           "

        For i = 1 To Len(texto)
            vPos = InStr(1, vComAcento, Mid(texto, i, 1))
            If vPos > 0 Then
                Mid(texto, i, 1) = Mid(vSemAcento, vPos, 1)
            End If
        Next
        RemoveAcentos = texto
    End Function

    Public Function RemoverCaracteres(ByVal Texto As String) As String

        If Texto = "" Then Exit Function
        Texto = UCase(Texto)
        Texto = Replace(Texto, "Á", "A")
        Texto = Replace(Texto, "É", "E")
        Texto = Replace(Texto, "Í", "I")
        Texto = Replace(Texto, "Ó", "O")
        Texto = Replace(Texto, "Ú", "U")
        Texto = Replace(Texto, "Ã", "A")
        Texto = Replace(Texto, "Õ", "O")
        Texto = Replace(Texto, "Ç", "C")
        Texto = Replace(Texto, "Ü", "U")
        Texto = Replace(Texto, "Ê", "E")
        Texto = Replace(Texto, "À", "A")
        Texto = Replace(Texto, "Â", "A")
        Texto = Replace(Texto, "?", " ")
        Texto = Replace(Texto, "¿", " ")
        Texto = Replace(Texto, "º", " ")
        Texto = Replace(Texto, "ª", " ")
        Texto = Replace(Texto, "", " ")
        Texto = Replace(Texto, "[", " ")
        Texto = Replace(Texto, "]", " ")
        Texto = Replace(Texto, "'", " ")

        Dim sTmp As String = ""
        For x As Int16 = 0 To Texto.Length - 1
            Select Case Asc(Texto.Substring(x, 1))
                Case 47 To 57, 65 To 90, 97 To 122, 32, 13, 14, 17, 167, 168
                Case Else
                    Texto.Replace(Texto.Substring(x, 1), "")
            End Select
        Next

        Return Texto
    End Function

    Public Function RemoverCaracteresXML(ByVal Texto As String) As String

        If Texto = "" Then Exit Function
        Texto = Replace(Texto, "Á", "A")
        Texto = Replace(Texto, "É", "E")
        Texto = Replace(Texto, "Í", "I")
        Texto = Replace(Texto, "Ó", "O")
        Texto = Replace(Texto, "Ú", "U")
        Texto = Replace(Texto, "Ã", "A")
        Texto = Replace(Texto, "Õ", "O")
        Texto = Replace(Texto, "Ç", "C")
        Texto = Replace(Texto, "Ü", "U")
        Texto = Replace(Texto, "Ê", "E")
        Texto = Replace(Texto, "À", "A")
        Texto = Replace(Texto, "Â", "A")
        Texto = Replace(Texto, "¿", " ")
        Texto = Replace(Texto, "º", " ")
        Texto = Replace(Texto, "ª", " ")
        Texto = Replace(Texto, "", " ")
        Texto = Replace(Texto, "[", " ")
        Texto = Replace(Texto, "]", " ")
        Texto = Replace(Texto, "'", " ")

        Dim sTmp As String = ""
        For x As Int16 = 0 To Texto.Length - 1
            Select Case Asc(Texto.Substring(x, 1))
                Case 47 To 57, 65 To 90, 97 To 122, 32, 13, 14, 17, 167, 168
                Case Else
                    Texto.Replace(Texto.Substring(x, 1), "")
            End Select
        Next

        Return Texto
    End Function

    Function ValidaAnoMes(ByVal sPeriodo As String) As Boolean
        Dim iAno As Int32
        Dim iMes As Int16
        Dim sErro As String = ""
        Dim sAnoMes As String = ""
        Dim bRet As Boolean = True

        sPeriodo = RetiraMascara(sPeriodo)

        If sPeriodo = "" Then Return True
        If sPeriodo.ToString.Length < 6 Then
            mostraMensagem = True
            Return False
        End If

        Try
            iAno = Mid(sPeriodo, 1, 4)
            iMes = Mid(sPeriodo, 5, 2)

            'Validações 
            If Not ValidaAno(iAno) Then
                bRet = False
                mostraMensagem = False
                Exit Function
            End If

            If Not ValidaMes(iMes) Then
                bRet = False
                mostraMensagem = False
                Exit Function
            End If


            If bRet Then sAnoMes = iAno & iMes

        Catch ex As Exception
            msgErro("Período inválido")
            bRet = False
            mostraMensagem = False
        End Try

        Return bRet
    End Function

    Function ValidaAno(ByVal iAno As Int16) As Boolean
        Dim bRet As Boolean

        Try
            'Validações 
            bRet = (iAno > 1500) And (iAno < 3000)
            If Not bRet Then
                msgErro("Ano inválido")
            End If

        Catch ex As Exception
            msgErro("Ano inválido")
            bRet = False
        End Try

        Return bRet
    End Function

    Function ValidaMes(ByVal iMes As Int16) As Boolean
        Dim sErro As String = ""
        Dim bRet As Boolean = True

        Try
            'Validações 
            bRet = (iMes >= 1) And (iMes <= 12)
            If Not bRet Then
                msgErro("Mês inválido")
            End If
        Catch ex As Exception
            msgErro("Ano inválido")
        End Try

        Return bRet
    End Function

    Function ConverterNumeroDescricao(ByVal sNum As String, ByRef sDescricao As String, ByVal sCountry As String) As Boolean
        Dim iMax As Integer
        Dim iDec As Integer
        Dim iAux As Integer
        Dim dMax As Double
        Dim sOutput As String
        Dim sAux As String
        Dim iUse As Integer
        Dim iUnidades As Integer
        Dim iLen As Integer
        Static iStart As Integer
        Dim bRet As Boolean = True
        sNum = Replace(Replace(sNum, ".", ""), ",", ".")

        Try

            If iStart = 0 Then
                InicializaValoresTabelas()
                iStart = 1
            End If

            If Len(sNum) = 0 Then

                ConverterNumeroDescricao = False
                Exit Function
            End If

            iDec = InStr(sNum, ".")
            If iDec = 0 Then
                iDec = InStr(sNum, ",")
                If iDec <> 0 Then
                    iAux = InStr(iDec + 1, sNum, ",")
                    If iAux <> 0 Then
                        ConverterNumeroDescricao = False
                        Exit Function
                    End If
                End If
            End If

            If iDec <> 0 Then
                If Len(sNum) - iDec < 2 Then
                    sNum = sNum + "0"
                End If
            End If

            If iDec <> 0 Then
                iMax = Int((iDec - 1) / 3)
            Else
                iMax = Int(Len(sNum) / 3)
            End If

            If iDec <> 0 Then
                dMax = (iDec - 1) / 3
            Else
                dMax = Len(sNum) / 3
            End If

            iLen = Len(sNum)
            If iDec <> 0 Then
                iLen = iDec - 1
            End If

            If iMax <> dMax Then
                iMax = iMax + 1
                sNum = StrDup(iMax * 3 - iLen, "0") + sNum
            End If

            iDec = InStr(sNum, ".")
            If iDec = 0 Then
                iDec = InStr(sNum, ",")
                If iDec <> 0 Then
                    iAux = InStr(iDec + 1, sNum, ",")
                    If iAux <> 0 Then
                        ConverterNumeroDescricao = False
                        Exit Function
                    End If
                    iAux = InStr(sNum, ".")
                    If iAux <> 0 Then
                        ConverterNumeroDescricao = False
                        Exit Function
                    End If
                End If
            Else
                iAux = InStr(iDec + 1, sNum, ".")
                If iAux <> 0 Then
                    ConverterNumeroDescricao = False
                    Exit Function
                End If
                iAux = InStr(sNum, ",")
                If iAux <> 0 Then
                    ConverterNumeroDescricao = False
                    Exit Function
                End If
            End If

            iLen = Len(sNum)
            If iDec <> 0 Then
                iLen = iDec - 1
            End If

            iAux = iMax

            sOutput = ""

            Do
                sAux = Mid(sNum, iLen - (iAux * 3) + 1, 3)
                iUse = False
                Select Case iAux
                    Case 1
                        If Mid(sAux, 1, 1) <> "0" Then
                            If Mid(sAux, 2, 1) = "0" And Mid(sAux, 3, 1) = "0" And iMax > 1 Then
                                sOutput = sOutput + "E "
                            End If
                            If (Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0") And Mid(sAux, 1, 1) = "1" Then
                                sOutput = sOutput + "CENTO E "
                            Else
                                sOutput = sOutput + M_tTerceiros(Val(Mid(sAux, 1, 1)))
                                If Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + "E "
                                End If
                            End If
                            iUse = True
                            iUnidades = True
                        End If
                        If Mid(sAux, 2, 1) <> "0" Then
                            If Mid(sAux, 1, 1) = "0" And iMax > 1 Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) = "1" Then
                                If Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + M_tDezenas(Val(Mid(sAux, 3, 1)))
                                    iUnidades = False
                                Else
                                    sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                    iUnidades = True
                                End If
                            Else
                                sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                iUnidades = True
                            End If
                            iUse = True
                        End If
                        If iUnidades = True Or Mid(sAux, 1, 2) = "00" Then
                            If Mid(sAux, 1, 2) = "00" And Mid(sAux, 3, 1) <> "0" And iMax > 1 Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) <> "0" And Mid(sAux, 3, 1) <> "0" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 3, 1) <> "0" Or iUse = False Then
                                If Val(sAux) <> 0 Then
                                    sOutput = sOutput + M_tPrimeiros(Val(Mid(sAux, 3, 1)))
                                End If
                            End If
                        End If
                        If Right(sOutput, 1) <> " " Then
                            sOutput = sOutput + " "
                        End If
                        If Val(sAux) = 1 Then
                            If iMax > 1 Then
                                sOutput = sOutput + GetDescricaoMoeda(sCountry, 0)
                            Else
                                sOutput = sOutput + GetDescricaoMoeda(sCountry, 1)
                            End If
                        ElseIf Val(sAux) <> 0 And Val(sAux) <> 1 Then
                            sOutput = sOutput + GetDescricaoMoeda(sCountry, 0)
                        ElseIf Val(sAux) = 0 And iMax > 1 Then
                            If Val(Mid(sNum, iLen - 5, 6)) = 0 Then
                                sOutput = sOutput + GetDescricaoMoeda(sCountry, 2)
                            Else
                                sOutput = sOutput + GetDescricaoMoeda(sCountry, 0)
                            End If
                        End If
                    Case 2 ' Mil
                        If Mid(sAux, 1, 1) <> "0" Then
                            If (Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0") And Mid(sAux, 1, 1) = "1" Then
                                sOutput = sOutput + "CENTO E "
                            Else
                                sOutput = sOutput + M_tTerceiros(Val(Mid(sAux, 1, 1)))
                                If Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + "E "
                                End If
                            End If
                            iUse = True
                            iUnidades = True
                        End If
                        If Mid(sAux, 2, 1) <> "0" Then
                            If Mid(sAux, 1, 1) = "0" And iMax > 2 And Mid(sNum, iLen - 2, 3) = "000" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) = "1" Then
                                If Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + M_tDezenas(Val(Mid(sAux, 3, 1)))
                                    iUnidades = False
                                Else
                                    sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                    iUnidades = True
                                End If
                            Else
                                sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                iUnidades = True
                            End If
                            iUse = True
                        End If
                        If iUnidades = True Or Mid(sAux, 1, 2) = "00" Then
                            If Mid(sAux, 1, 2) = "00" And Mid(sAux, 3, 1) <> "0" And iMax > 2 And Mid(sNum, iLen - 2, 3) = "000" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) <> "0" And Mid(sAux, 3, 1) <> "0" Then
                                sOutput = sOutput + "E "
                            End If
                            If Not sAux = "001" Then
                                If Mid(sAux, 3, 1) <> "0" Or iUse = False Then
                                    If Val(sAux) <> 0 Then
                                        sOutput = sOutput + M_tPrimeiros(Val(Mid(sAux, 3, 1)))
                                    End If
                                End If
                            End If
                        End If
                        If Right(sOutput, 1) <> " " Then
                            sOutput = sOutput + " "
                        End If
                        If Val(sAux) <> 0 Then
                            If Right(sOutput, 1) <> " " Then
                                sOutput = sOutput + " "
                            End If
                            sOutput = sOutput + "MIL "
                        End If
                    Case 3 ' Milhão
                        If Mid(sAux, 1, 1) <> "0" Then
                            If Mid(sAux, 2, 1) = "0" And Mid(sAux, 3, 1) = "0" And iMax > 3 And Val(Mid(sNum, iLen - 5, 6)) = 0 Then
                                sOutput = sOutput + "E "
                            End If
                            If (Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0") And Mid(sAux, 1, 1) = "1" Then
                                sOutput = sOutput + "CENTO E "
                            Else
                                sOutput = sOutput + M_tTerceiros(Val(Mid(sAux, 1, 1)))
                                If Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + "E "
                                End If
                            End If
                            iUse = True
                            iUnidades = True
                        End If
                        If Mid(sAux, 2, 1) <> "0" Then
                            If Mid(sAux, 1, 1) = "0" And iMax > 3 And Mid(sNum, iLen - 5, 6) = "000000" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) = "1" Then
                                If Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + M_tDezenas(Val(Mid(sAux, 3, 1)))
                                    iUnidades = False
                                Else
                                    sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                    iUnidades = True
                                End If
                            Else
                                sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                iUnidades = True
                            End If
                            iUse = True
                        End If
                        If iUnidades = True Or Mid(sAux, 1, 2) = "00" Then
                            If Mid(sAux, 1, 2) = "00" And Mid(sAux, 3, 1) <> "0" And iMax > 3 And Mid(sNum, iLen - 5, 6) = "000000" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) <> "0" And Mid(sAux, 3, 1) <> "0" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 3, 1) <> "0" Or iUse = False Then
                                If Val(sAux) <> 0 Then
                                    sOutput = sOutput + M_tPrimeiros(Val(Mid(sAux, 3, 1)))
                                End If
                            End If
                        End If
                        If Right(sOutput, 1) <> " " Then
                            sOutput = sOutput + " "
                        End If
                        If Not (Mid(sAux, 1, 3) = "000" And iMax > 3) Then
                            If Val(sAux) = 1 Then
                                sOutput = sOutput + "MILHÃO "
                            Else
                                sOutput = sOutput + "MILHÕES "
                            End If
                        End If
                    Case 4 ' Milhares de Milhão
                        If Mid(sAux, 1, 1) <> "0" Then
                            If Mid(sAux, 2, 1) = "0" And Mid(sAux, 3, 1) = "0" And iMax > 4 And Mid(sNum, iLen - 8, 9) = "000000000" Then
                                sOutput = sOutput + "E "
                            End If
                            If (Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0") And Mid(sAux, 1, 1) = "1" Then
                                sOutput = sOutput + "CENTO E "
                            Else
                                sOutput = sOutput + M_tTerceiros(Val(Mid(sAux, 1, 1)))
                                If Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + "E "
                                End If
                            End If
                            iUse = True
                            iUnidades = True
                        End If
                        If Mid(sAux, 2, 1) <> "0" Then
                            If Mid(sAux, 1, 1) = "0" And iMax > 4 And Mid(sNum, iLen - 8, 9) = "000000000" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) = "1" Then
                                If Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + M_tDezenas(Val(Mid(sAux, 3, 1)))
                                    iUnidades = False
                                Else
                                    sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                    iUnidades = True
                                End If
                            Else
                                sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                iUnidades = True
                            End If
                            iUse = True
                        End If
                        If iUnidades = True Or Mid(sAux, 1, 2) = "00" Then
                            If Mid(sAux, 1, 2) = "00" And Mid(sAux, 3, 1) <> "0" And iMax > 4 And Mid(sNum, iLen - 8, 9) = "000000000" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) <> "0" And Mid(sAux, 3, 1) <> "0" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 3, 1) <> "0" Or iUse = False Then
                                If Val(sAux) <> 0 Then
                                    sOutput = sOutput + M_tPrimeiros(Val(Mid(sAux, 3, 1)))
                                End If
                            End If
                        End If
                        If Right(sOutput, 1) <> " " Then
                            sOutput = sOutput + " "
                        End If
                        If Not (Mid(sAux, 1, 3) = "000" And iMax > 3) Then
                            If Val(sAux) = 1 Then
                                sOutput = sOutput + "MILHAR DE MILHÃO "
                            Else
                                sOutput = sOutput + "MILHARES DE MILHÕES "
                            End If
                        End If
                    Case 5 ' Biliões
                        If Mid(sAux, 1, 1) <> "0" Then
                            If Mid(sAux, 2, 1) = "0" And Mid(sAux, 3, 1) = "0" And iMax > 5 Then
                                sOutput = sOutput + "E "
                            End If
                            If (Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0") And Mid(sAux, 1, 1) = "1" Then
                                sOutput = sOutput + "CENTO E "
                            Else
                                sOutput = sOutput + M_tTerceiros(Val(Mid(sAux, 1, 1)))
                                If Mid(sAux, 2, 1) <> "0" Or Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + "E "
                                End If
                            End If
                            iUse = True
                            iUnidades = True
                        End If
                        If Mid(sAux, 2, 1) <> "0" Then
                            If Mid(sAux, 1, 1) = "0" And iMax > 5 Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) = "1" Then
                                If Mid(sAux, 3, 1) <> "0" Then
                                    sOutput = sOutput + M_tDezenas(Val(Mid(sAux, 3, 1)))
                                    iUnidades = False
                                Else
                                    sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                    iUnidades = True
                                End If
                            Else
                                sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 2, 1)))
                                iUnidades = True
                            End If
                            iUse = True
                        End If
                        If iUnidades = True Or Mid(sAux, 1, 2) = "00" Then
                            If Mid(sAux, 1, 2) = "00" And Mid(sAux, 3, 1) <> "0" And iMax > 5 Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 2, 1) <> "0" And Mid(sAux, 3, 1) <> "0" Then
                                sOutput = sOutput + "E "
                            End If
                            If Mid(sAux, 3, 1) <> "0" Or iUse = False Then
                                If Val(sAux) <> 0 Then
                                    sOutput = sOutput + M_tPrimeiros(Val(Mid(sAux, 3, 1)))
                                End If
                            End If
                        End If
                        If Right(sOutput, 1) <> " " Then
                            sOutput = sOutput + " "
                        End If
                        If Val(sAux) = 1 Then
                            sOutput = sOutput + "BILHÃO "
                        Else
                            sOutput = sOutput + "BILHÕES "
                        End If
                End Select
                iAux = iAux - 1
            Loop While iAux <> 0

            If iDec <> 0 Then
                sAux = Mid(sNum, iDec + 1, Len(sNum) - iDec + 1)
                If sAux = 0 Then
                    GoTo fConverter
                End If
                If Not Val(Mid(sNum, 1, iLen)) = 0 Then
                    sOutput = sOutput + " E "
                End If
                If Mid(sAux, 1, 1) <> "0" Then
                    If Mid(sAux, 1, 1) = "1" Then
                        If Mid(sAux, 2, 1) <> "0" Then
                            sOutput = sOutput + M_tDezenas(Val(Mid(sAux, 2, 1)))
                            iUse = False
                        Else
                            sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 1, 1)))
                            iUse = False
                        End If
                    Else
                        sOutput = sOutput + M_tSegundos(Val(Mid(sAux, 1, 1)))
                        iUse = True
                    End If
                ElseIf Mid(sAux, 2, 1) <> "0" Then
                    iUse = True
                End If
                If iUse Then
                    If Mid(sAux, 2, 1) <> "0" And Mid(sAux, 1, 1) <> 0 Then
                        sOutput = sOutput + "E " + M_tPrimeiros(Val(Mid(sAux, 2, 1)))
                    ElseIf Mid(sAux, 2, 1) <> "0" And Mid(sAux, 1, 1) = 0 Then
                        sOutput = sOutput + M_tPrimeiros(Val(Mid(sAux, 2, 1)))
                    End If
                End If
                If Val(Mid(sNum, iDec + 1, 2)) = 1 Then
                    sOutput = sOutput + GetDescricaoMoeda(sCountry, 3)
                ElseIf Val(Mid(sNum, iDec + 1, 2)) > 1 Then
                    sOutput = sOutput + GetDescricaoMoeda(sCountry, 4)
                End If
            End If

            If Val(Mid(sNum, 1, iLen)) = 0 And Val(sAux) = 0 Then
                ConverterNumeroDescricao = False
                Exit Function
            End If

fConverter:
            sDescricao = Trim(sOutput)
            bRet = True
        Catch ex As Exception
            msgErro("Conversão inválida")
            bRet = False
        End Try
        Return bRet
    End Function

    Sub InicializaValoresTabelas()
        Try
            M_tTerceiros(1) = "CEM "
            M_tTerceiros(2) = "DUZENTOS "
            M_tTerceiros(3) = "TREZENTOS "
            M_tTerceiros(4) = "QUATROCENTOS "
            M_tTerceiros(5) = "QUINHENTOS "
            M_tTerceiros(6) = "SEISCENTOS "
            M_tTerceiros(7) = "SETECENTOS "
            M_tTerceiros(8) = "OITOCENTOS "
            M_tTerceiros(9) = "NOVECENTOS "

            M_tSegundos(1) = "DEZ "
            M_tSegundos(2) = "VINTE "
            M_tSegundos(3) = "TRINTA "
            M_tSegundos(4) = "QUARENTA "
            M_tSegundos(5) = "CINQUENTA "
            M_tSegundos(6) = "SESSENTA "
            M_tSegundos(7) = "SETENTA "
            M_tSegundos(8) = "OITENTA "
            M_tSegundos(9) = "NOVENTA "

            M_tPrimeiros(0) = "ZERO "
            M_tPrimeiros(1) = "UM "
            M_tPrimeiros(2) = "DOIS "
            M_tPrimeiros(3) = "TRES "
            M_tPrimeiros(4) = "QUATRO "
            M_tPrimeiros(5) = "CINCO "
            M_tPrimeiros(6) = "SEIS "
            M_tPrimeiros(7) = "SETE "
            M_tPrimeiros(8) = "OITO "
            M_tPrimeiros(9) = "NOVE "

            M_tDezenas(1) = "ONZE "
            M_tDezenas(2) = "DOZE "
            M_tDezenas(3) = "TREZE "
            M_tDezenas(4) = "QUATORZE "
            M_tDezenas(5) = "QUINZE "
            M_tDezenas(6) = "DEZESSEIS "
            M_tDezenas(7) = "DEZESSETE "
            M_tDezenas(8) = "DEZOITO "
            M_tDezenas(9) = "DEZENOVE "
        Catch ex As Exception
            msgAviso("Descrição inválida!")
        End Try
    End Sub

    Function GetDescricaoMoeda(ByVal sCountry As String, ByVal iTipo As Integer) As String
        GetDescricaoMoeda = ""
        Try
            Select Case sCountry
                Case "PRT"
                    Select Case iTipo
                        Case 0 : GetDescricaoMoeda = "ESCUDOS"
                        Case 1 : GetDescricaoMoeda = "ESCUDO"
                        Case 2 : GetDescricaoMoeda = "DE ESCUDOS"
                        Case 3 : GetDescricaoMoeda = "CENTAVO"
                        Case 4 : GetDescricaoMoeda = "CENTAVOS"
                    End Select
                Case "BRL"
                    Select Case iTipo
                        Case 0 : GetDescricaoMoeda = "REAIS"
                        Case 1 : GetDescricaoMoeda = "REAL"
                        Case 2 : GetDescricaoMoeda = "DE REAIS"
                        Case 3 : GetDescricaoMoeda = "CENTAVO"
                        Case 4 : GetDescricaoMoeda = "CENTAVOS"
                    End Select
            End Select

        Catch ex As Exception
            msgAviso("Descrição inválida!")
        End Try
    End Function

    Public Function CalculaAnoMes(ByVal sAnoMes As String, ByVal iMesesAdicionais As Integer, ByVal sSinal As String) As String
        Dim iAno As Integer
        Dim iMes As Integer

        Try
            CalculaAnoMes = True

            iAno = CInt(Mid$(sAnoMes, 1, 4))
            iMes = CInt(Mid$(sAnoMes, 5, 2))

            'Validações ***************************************************************
            If (iAno > 3000) Or (iAno < 1500) Then
                Err.Raise(1, "Função CalculaAnoMes", "Data (ano) inválida")
            End If

            If (iMes > 12) Or (iMes < 1) Then
                Err.Raise(1, "Função CalculaAnoMes", "Data (mês) inválida")
            End If
            '***************************************************************************

            Select Case sSinal
                Case "+" : iMes = iMes + iMesesAdicionais
                Case "-" : iMes = iMes - iMesesAdicionais
            End Select

            If iMes = 0 Or iMes < 0 Then
                iAno = iAno - 1
                If iMes < 0 Then
                    iMes = 12 + iMes
                Else
                    iMes = 12
                End If
            ElseIf iMes <> 12 Then
                If (iMes \ 12) > 0 Then
                    Select Case sSinal
                        Case "+" : iAno = iAno + (iMes \ 12)
                        Case "-" : iAno = iAno - (iMes \ 12)
                    End Select
                    iMes = iMes Mod 12
                End If
            End If

            Return CStr(iAno) + FormataNumero(CStr(iMes), 2)
        Catch ex As Exception
            Return ""
            msgAviso("Cálculo de Ano/Mês inválido!")
        End Try
    End Function

    Public Function ProximoDiaSemana(ByRef dDia As Date, ByVal iDiaSemana01 As Int16, ByVal iDiaSemana02 As Int16) As Boolean
        'Procura Novo Vencimento de Acordo com o Dia da Semana
        Do While Not (Weekday(dDia, FirstDayOfWeek.Sunday) = iDiaSemana01 Or Weekday(dDia, FirstDayOfWeek.Sunday) = iDiaSemana02)
            dDia = DateAdd("d", 1, dDia)
        Loop
    End Function

    Public Function QuebraLinha(ByVal sLinha As String, ByVal iQtdCarater As Int32) As String
        Dim iTamanho As Int16 = 0
        Dim iContador As Int16 = 1
        Dim iContadorTotal As Int16 = 1
        Dim i As Int16 = 0
        Dim sLinhaFormatada As String = ""
        Dim sCaracter As String = ""
        Dim iPosicao As Int32 = 1
        iTamanho = Len(sLinha)
        Try
            If iTamanho > iQtdCarater Then
                Do While iContadorTotal <= iTamanho
                    sCaracter = ""
                    sCaracter = Mid(sLinha, iContador, 1)

                    If sCaracter = " " And iContador >= iQtdCarater Then
                        sLinhaFormatada += Mid(sLinha, iPosicao, iContador - 1).Trim
                        iContadorTotal += iContador - 1
                        If iContadorTotal < iTamanho Then
                            sLinhaFormatada += vbCr
                        End If
                        iPosicao += iContador - 1
                        iContador = 0
                    End If
                    iContador += 1
                Loop
            Else
                sLinhaFormatada = sLinha
            End If
        Catch ex As Exception
            sLinhaFormatada = ""
        End Try

        Return sLinhaFormatada

    End Function

    ' Manipula os Eventos do Form
    Public Sub DestacaFoco(ByVal ctrlParent As Control)
        Dim ctrl As Control
        Dim text As TextBox
        Dim mask As MaskedTextBox
        Dim gera As Boolean

        For Each ctrl In ctrlParent.Controls
            gera = True
            If TypeOf ctrl Is TextBox Or _
                TypeOf ctrl Is ComboBox Or _
                TypeOf ctrl Is MaskedTextBox Or _
                TypeOf ctrl Is DataGridTextBox Then
                If TypeOf ctrl Is TextBox Then
                    text = CType(ctrl, TextBox)
                    If text.ReadOnly = True Then
                        gera = False
                    End If
                End If

                If TypeOf ctrl Is MaskedTextBox Then
                    mask = CType(ctrl, MaskedTextBox)
                    If mask.ReadOnly = True Then
                        gera = False
                    End If
                End If

                If gera Then
                    AddHandler ctrl.Leave, AddressOf ObjetodeSelecionado
                    AddHandler ctrl.Enter, AddressOf ObjetoSelecionado
                End If

            End If
            If ctrl.HasChildren Then
                DestacaFoco(ctrl)
            End If
        Next
    End Sub

    ' Função Chamada quando o Controle perde Foco
    Private Sub ObjetodeSelecionado(ByVal sender As Object, ByVal e As System.EventArgs)
        sender.BackColor = Color.White
    End Sub

    ' Função Chamada quando o Controle ganha Foco
    Private Sub ObjetoSelecionado(ByVal sender As Object, ByVal e As System.EventArgs)
        sender.BackColor = Color.Khaki
    End Sub

    Public Function ValidaCaracteresEmail(ByVal key As String, Optional ByVal blnSeparador As Boolean = False) As Boolean
        'Permite letras, numeros, @, ., delete, backspace, ;(separador)
        Return Not ((Convert.ToInt32(key) >= 48 And Convert.ToInt32(key) <= 57) Or _
               (Convert.ToInt32(key) >= 64 And Convert.ToInt32(key) <= 122) Or _
               (Convert.ToInt32(key) = Keys.Delete Or Convert.ToInt32(key) = Keys.Back Or Convert.ToInt32(key) = 46 Or IIf(blnSeparador And Convert.ToInt32(key) = 44, True, False)))
    End Function

    Public Function gfTravarCampos(ByVal objCampo As Object, ByVal blnTravar As Boolean)
        'Alteração das propriedades para bloquear campo
        objCampo.Enabled = Not blnTravar
        objCampo.backcolor = IIf(blnTravar, Color.Gainsboro, Color.White)
        objCampo.tabstop = Not blnTravar
    End Function

    Public Function ValidaSenhaAlfaNumerica(ByVal senha As String) As Boolean
        Dim possuiLetra As Boolean = False
        Dim possuiNum As Boolean = False
        Dim possuiEsp As Boolean = False
        For Each c As Char In senha
            possuiLetra = IIf(possuiLetra, possuiLetra, [Char].IsLetter(c))
            possuiNum = IIf(possuiNum, possuiNum, [Char].IsNumber(c))
            possuiEsp = IIf(possuiEsp, possuiEsp, ([Char].IsSymbol(c) OrElse [Char].IsPunctuation(c)))
            If possuiLetra AndAlso possuiNum AndAlso Not possuiEsp Then
                Return True
            End If
        Next
        Return False
    End Function

    Public Function executaSql(ByVal sql As String) As DataTable
        Dim dt As New DataTable
        Try
            Dim da As New OracleDataAdapter
            Dim ds As New DataSet
            Dim cmd = New OracleCommand(sql, oConn)
            cmd.Transaction = oTrans
            da.SelectCommand = cmd
            da.Fill(ds)
            dt = ds.Tables(0)
        Catch ex As Exception
            Throw ex
        Finally
            executaSql = dt
        End Try
        Return dt
    End Function

    Public Function BuscaProximoDiaUtil(ByRef dData As Date) As Date
        Dim bIndFeriado As Boolean
        Return dData
    End Function

    ''' <summary>
    ''' Funcao que exporta cada row do datatable como um item para o arquivo txt com as colunas separadas por virgula.
    ''' </summary>
    ''' <param name="dataTable">Dados que serao serializados para o txt</param>
    ''' <param name="path">Caminho onde sera gerado o arquivo txt</param>
    ''' <returns>Retorna um valor booleano. True se a exportacao ocorrer corretamente, caso contrario, False.</returns>
    ''' <remarks>O datatable e passado por parametro da funcao e assim como o caminho</remarks>
    Public Function ExportDatatableToFile(ByVal dataTable As DataTable, ByVal path As String) As Boolean
        Dim stringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder()
        Dim dataTableExportado As Boolean

        Try
            ' Cria arquivo e desserializa o data table no arquivo
            Using streamWriter As System.IO.StreamWriter = New System.IO.StreamWriter(path)
                ' Constroi cabecalho do arquivo
                For Each head As DataColumn In dataTable.Columns
                    stringBuilder.Append(head.ColumnName()).Append(Chr(44))
                Next
                stringBuilder.Remove(stringBuilder.Length - 1, 1)
                streamWriter.WriteLine(stringBuilder.ToString())
                stringBuilder.Clear()
                ' Exporta cada row para uma string e grava no arquivo
                For Each row As DataRow In dataTable.Rows
                    For Each item As DataColumn In dataTable.Columns
                        stringBuilder.Append(Chr(34)).Append(row.Item(item).ToString()).Append(Chr(34)).Append(Chr(44))
                    Next
                    stringBuilder.Remove(stringBuilder.Length - 1, 1)
                    streamWriter.WriteLine(stringBuilder.ToString())
                    stringBuilder.Clear()
                Next
            End Using
        Catch ex As Exception
            dataTableExportado = False
            Throw
        Finally
            dataTableExportado = True
        End Try

        Return dataTableExportado
    End Function

    Public Function DataRowCollectionToString(ByVal dataRowCollection As DataRowCollection, ByVal nomeColuna As String, ByVal separador As String, ByVal entreAspas As Boolean) As String
        Dim resultado As String = String.Empty

        If dataRowCollection Is Nothing OrElse dataRowCollection.Count = 0 Then Return String.Empty

        For Each row As DataRow In dataRowCollection
            If entreAspas Then
                resultado &= "'" & row(nomeColuna).ToString() & "'" & separador
            Else
                resultado &= row(nomeColuna).ToString() & separador
            End If
        Next

        If resultado.Length >= separador.Length Then
            resultado = resultado.Substring(0, resultado.Length - separador.Length)
        End If

        Return resultado
    End Function

    Public Sub IniciarTransacao()

        If IsNothing(oTrans) Then

            oTrans = oConn.BeginTransaction

        Else

            oTrans = Nothing
            oTrans = oConn.BeginTransaction

        End If

    End Sub

    Public Function ExecuteSQLReturnException(ByVal sSQL As String) As Boolean
        Dim lCmd As New OracleCommand
        Dim bRetorno As Boolean

        If Not IsNothing(oTrans) Then lCmd.Transaction = oTrans

        Try
            If oConn.State = ConnectionState.Closed Then
                Throw New Exception("Erro ao abrir banco de dados, faça novo login no sistema")
                Dim frm As New frmLogin
                frm.ShowDialog()
            End If

            lCmd.Connection = oConn
            lCmd.CommandText = sSQL
            lCmd.CommandType = CommandType.Text
            lCmd.ExecuteNonQuery()
            bRetorno = True
        Catch ex As Exception
            Throw ex
        Finally
        End Try

        Return bRetorno
    End Function

End Module
