﻿Public Class MensagemParametrizavelEntity

    Public Property CodigoMensagemParametrizavel() As Decimal

    Public Property CodigoUnidadeNegocio() As Decimal

    Public Property CodigoDominioTipoEmpresa() As String

    Public Property CodigoDominioItemTipoEmpresa() As Decimal

    Public Property CodigoDominioMensagem() As String

    Public Property CodigoDominioItemMensagem() As Decimal

    Public Property DataInicioVigencia() As Date

    Public Property DataFinalVigencia() As Date

    Public Property DescricaoMensagem() As String

    Public Property NumeroLinha() As Decimal

    Public Property CodigoDominioPrioridade() As String

    Public Property CodigoDominioItemPrioridade() As Decimal

    Public Property CodigoDominioBlocoMensagem() As String

    Public Property CodigoDominioItemBlocoMensagem() As Decimal

    Public Property CodigoUsuarioInclusao() As String

    Public Property DataUsuarioInclusao() As Date

    Public Property CodigoUsuarioAlteracao() As String

    Public Property DataUsuarioAlteracao() As Date?

    ' As colunas abaixo são usadas apenas para consultas
    Public Property Status() As String

    Public Property DescricaoDominioTipoEmpresa() As String

    Public Property DescricaoDominioMensagem() As String

    Public Property DescricaoDominioPrioridade() As String

    Public Property DescricaoDominioBlocoMensagem() As String

End Class
